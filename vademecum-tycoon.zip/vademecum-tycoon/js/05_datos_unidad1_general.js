/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/05_datos_unidad1_general.js
   Responsabilidad: Base de Conocimiento Clínico de la Unidad 1 con extracción
   íntegra y literal del PDF "TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS"
   (Formas líquidas, sólidas, semisólidas, dispositivos inhalatorios unidosis y
   multidosis, vías enterales, tópicas, parenterales y los casos clínicos del PDF).
   ========================================================================== */

(function (FT) {
  'use strict';

  var farmacosUnidad1 = [
    {
      id: 'farm_salbutamol_t2',
      dci: 'Salbutamol',
      nombresTemario: ['Salbutamol para nebulizador', 'Salbutamol jarabe', 'Cartucho presurizado'],
      codigoATC: 'R03AC02',
      familia: 'Broncodilatadores (Antiasmáticos · Vía inhalatoria vs Vía oral)',
      formasYVias: [
        { id: 'nebulizador_inh', texto: 'Solución para nebulizador: gotas líquidas dispersas en nube de gas (Vía Inhalatoria)', via: 'Inhalatoria', biodisponibilidad: 'Absorción muy rápida desde los alvéolos; de elección en crisis aguda de asma en Urgencias' },
        { id: 'cartucho_presurizado', texto: 'Cartucho presurizado: envase metálico con líquido + gas propelente (Vía Inhalatoria)', via: 'Inhalatoria', biodisponibilidad: 'Acción local bronquial rápida; requiere aprendizaje de técnica' },
        { id: 'jarabe_oral', texto: 'Jarabe: solución concentrada de azúcares en agua (Vía Oral)', via: 'Oral', biodisponibilidad: 'Inicio lento (¡Emergencias no!); descartado en crisis asmática aguda' }
      ],
      mecanismo: 'Broncodilatación local rápida por absorción alveolar directa cuando se administra por vía inhalatoria.',
      ladme: 'En crisis de asma bronquial con intensa falta de aire (Caso Clínico Tema 2, Pág. 52), el nebulizador actúa de forma inmediata en el árbol bronquial, mientras que el jarabe oral tiene un inicio lento inaceptable en urgencias.',
      cuidadoEnfermero: 'Educar al paciente en el manejo de formas complejas (nebulizadores y cartuchos presurizados). Al alta hospitalaria se sustituye la vía parenteral por polvo para inhalación.',
      mnemotecnia: '«En crisis de asma en Urgencias: ¡Vía oral en emergencias NO! Pon Salbutamol en nebulizador.»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 15, 20, 26, 39 y 52'
    },
    {
      id: 'farm_hidrocortisona_t2',
      dci: 'Hidrocortisona',
      nombresTemario: ['Hidrocortisona (polvo para preparación inyectable extemporánea)', 'Hidrocortisona (crema)'],
      codigoATC: 'H02AB09',
      familia: 'Corticoides (Vial liofilizado parenteral vs Crema tópica)',
      formasYVias: [
        { id: 'vial_extemporaneo_iv', texto: 'Vial en polvo seco/liofilizado para preparación inyectable extemporánea (Vía Parenteral IV)', via: 'Parenteral', biodisponibilidad: '100% sistémica inmediata tras reconstituir con líquido; de elección en UCI' },
        { id: 'crema_topica', texto: 'Crema de aplicación cutánea (Vía Tópica)', via: 'Tópica', biodisponibilidad: 'Efecto local cutáneo (eccemas, prurito); inútil en broncoespasmo grave en UCI' }
      ],
      mecanismo: 'Antiinflamatorio esteroideo sistémico de urgencia cuando se reconstituye el vial y se inyecta por vía intravenosa.',
      ladme: 'El vial contiene el fármaco en polvo seco o liofilizado y requiere añadir líquido estéril antes de su administración parenteral (preparación extemporánea).',
      cuidadoEnfermero: 'Precaución pediátrica del Tema 2 (Pág. 36): una crema con corticoide aplicada sobre la piel inflamada y dañada del bebé (eczema de pañal) pierde el carácter local y produce absorción y efectos SISTÉMICOS.',
      mnemotecnia: '«Si el asmático empeora y entra en la UCI, reconstituye el vial en polvo inyectable (la crema es para la piel).»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 8, 36 y 53'
    },
    {
      id: 'farm_metamizol_iv',
      dci: 'Metamizol',
      nombresTemario: ['Metamizol (inyectable · ampolla)'],
      codigoATC: 'N02BB02',
      familia: 'Antipiréticos y analgésicos parenterales',
      formasYVias: [
        { id: 'ampolla_parenteral', texto: 'Ampolla estéril de vidrio/plástico con 1 dosis en solución (Vía Parenteral IV/IM)', via: 'Parenteral', biodisponibilidad: 'Pasa directo a sangre o líquido tisular sin atravesar mucosa intestinal; evita el vómito' }
      ],
      mecanismo: 'Antipirético y analgésico de acción rápida.',
      ladme: 'En el paciente con neumonía hospitalaria, fiebre, tos húmeda y vómitos (Caso Clínico Tema 2, Pág. 54), evita la expulsión del fármaco que sufrirían los comprimidos de Aspirina o el jarabe de Paracetamol.',
      cuidadoEnfermero: 'Requiere técnica estéril; vigilar posible lesión tisular o flebitis como inconveniente de la vía parenteral.',
      mnemotecnia: '«Neumonía con fiebre y vómitos en planta: ni jarabe ni comprimido; ampolla de Metamizol inyectable.»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 8, 44 y 54'
    },
    {
      id: 'farm_paracetamol_efg',
      dci: 'Paracetamol',
      nombresTemario: ['Paracetamol STADAGEN 1 g EFG', 'Paracetamol (jarabe)', 'Paracetamol (supositorios)'],
      codigoATC: 'N02BE01',
      familia: 'Analgésicos y antipiréticos (Vía oral y Vía rectal)',
      formasYVias: [
        { id: 'jarabe_oral', texto: 'Jarabe: solución concentrada de azúcares en agua (Vía Oral)', via: 'Oral', biodisponibilidad: 'Enmascara sabor desagradable; fracasa si el paciente presenta vómitos' },
        { id: 'comp_eferv', texto: 'Comprimidos efervescentes (sales de ácido cítrico y bicarbonato que liberan CO2 en agua)', via: 'Oral', biodisponibilidad: 'Liberación previa del principio activo en el agua' },
        { id: 'supositorio_rectal', texto: 'Supositorio en base de crema de cacao o gelatina (Vía Rectal)', via: 'Rectal', biodisponibilidad: 'Útil en vómitos recurrentes o pacientes poco colaboradores, aunque de absorción irregular' }
      ],
      mecanismo: 'Antipirético y analgésico.',
      ladme: 'Por vía oral es segura, cómoda y económica, pero no es útil si hay náuseas y vómitos activos (Pág. 26). Por vía rectal es alternativa ante emesis si no se dispone de vía parenteral (Pág. 32).',
      cuidadoEnfermero: 'Para insertar un supositorio: 1) Quitar cobertura metálica, 2) Humedecer con agua o jalea lubricante hidrosoluble (como K-Y), 3) Empujar lentamente dentro del recto lo bastante profundo para que no salga (Pág. 33).',
      mnemotecnia: '«El jarabe lleva azúcar para el mal sabor; el efervescente lleva ácido cítrico y bicarbonato que sueltan CO2.»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 8, 10, 26, 32, 33 y 54'
    },
    {
      id: 'farm_aas_n02ba01',
      dci: 'Ácido acetilsalicílico',
      nombresTemario: ['Aspirina (comprimidos) · ATC: N02BA01'],
      codigoATC: 'N02BA01',
      familia: 'Derivados del ácido salicílico (Analgésico y antipirético)',
      formasYVias: [
        { id: 'comprimidos_orales', texto: 'Comprimidos obtenidos por compresión de polvo (pueden ranurarse · Vía Oral)', via: 'Oral', biodisponibilidad: 'Ineficaz en presencia de vómitos; irritante de la mucosa gástrica' }
      ],
      mecanismo: 'Analgésico, antipirético y antiinflamatorio.',
      ladme: 'Desglose ATC (Tema 1): N (Sistema Nervioso) 02 (Analgésicos) B (Otros analgésicos y antipiréticos) A (Ácido salicílico y derivados) 01. En el Caso Clínico del Tema 2 (Pág. 54) se descarta por ser vía oral en un paciente con vómitos.',
      cuidadoEnfermero: 'Los comprimidos convencionales fabricados por compresión de polvo pueden ranurarse (Pág. 10), a diferencia de los de cubierta entérica o liberación retardada.',
      mnemotecnia: '«Aspirina en comprimidos: código N02BA01, nunca en pacientes con vómitos activos.»',
      fuente: 'TEMA 01 (Pág. 14) y TEMA 02 (Págs. 10 y 54)'
    },
    {
      id: 'farm_inhaladores_dpi_t2',
      dci: 'Inhaladores de Polvo Seco (DPI)',
      nombresTemario: [
        'Unidosis: Handihaler®, Aerolizer®, Breezhaler®',
        'Multidosis: Accuhaler®, Turbuhaler®, Twisthaler®, Novolizer®, Nexthaler®, Ellipta®, Spiromax®, Easyhaler®'
      ],
      codigoATC: 'R03',
      familia: 'Formas farmacéuticas complejas o especiales (Vía Inhalatoria sin gas propelente)',
      formasYVias: [
        { id: 'dpi_unidosis', texto: 'Polvo seco UNIDOSIS: Handihaler®, Aerolizer®, Breezhaler® (Vía Inhalatoria)', via: 'Inhalatoria', biodisponibilidad: 'Sin gases propelentes; cargan una cápsula por toma' },
        { id: 'dpi_multidosis', texto: 'Polvo seco MULTIDOSIS: Accuhaler®, Turbuhaler®, Twisthaler®, Novolizer®, Nexthaler®, Ellipta®, Spiromax®, Easyhaler®', via: 'Inhalatoria', biodisponibilidad: 'Sin gases propelentes; múltiples dosis integradas para tratamiento domiciliario al alta' }
      ],
      mecanismo: 'Envases diseñados para permitir inhalar el medicamento directamente hacia los alvéolos sin utilizar gases propelentes.',
      ladme: 'Absorción rápida alveolar. Son el tratamiento antiasmático de elección al dar el ALTA hospitalaria (Caso Clínico Tema 2, Pág. 55) frente a los antiasmáticos inyectables.',
      cuidadoEnfermero: 'Al ser una forma farmacéutica compleja, requiere enseñar previamente la técnica inhalatoria al paciente para garantizar la adherencia terapéutica.',
      mnemotecnia: '«Los 3 Unidosis acaban en -haler/-lizer de cápsula suelta: Handi, Aero y Breez. Sin gas propelente.»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 14, 16, 17, 18 y 55'
    },
    {
      id: 'farm_nitroglicerina_buprenorfina_sl',
      dci: 'Nitroglicerina / Buprenorfina',
      nombresTemario: ['Nitroglicerina (sublingual y parches)', 'Buprenorfina (sublingual)'],
      codigoATC: 'C01DA02 / N02AE01',
      familia: 'Fármacos de Vía Sublingual y Vía Transdérmica (Evitan primer paso hepático)',
      formasYVias: [
        { id: 'sublingual_comp', texto: 'Comprimido sublingual debajo de la lengua (Vía Sublingual)', via: 'Sublingual', biodisponibilidad: 'Absorción rápida en minutos; evita el paso por el hígado' },
        { id: 'parche_transdermico', texto: 'Parche adhesivo transdérmico para cardiópatas (Vía Tópica Transdérmica)', via: 'Transdérmica', biodisponibilidad: 'Efecto SISTÉMICO por difusión lenta y prolongada; puede causar irritación local' }
      ],
      mecanismo: 'La vía sublingual busca efecto sistémico urgente en minutos; el parche transdérmico de nitroglicerina busca efecto sistémico sostenido.',
      ladme: 'No confundir Vía Sublingual (bajo la lengua, absorción muy rápida) con Vía Bucal (entre encía y mejilla, donde no debe moverse para lograr liberación prolongada; ambas evitan el paso hepático).',
      cuidadoEnfermero: 'Vigilar que el comprimido bucal no se desplace debajo de la lengua para evitar una absorción brusca no deseada (Pág. 28).',
      mnemotecnia: '«Nitroglicerina y Buprenorfina bajo la lengua: absorción en minutos y saltan el hígado.»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 27, 28 y 36'
    },
    {
      id: 'farm_diazepam_rectal',
      dci: 'Diazepam',
      nombresTemario: ['Diazepam rectal (enema / microenema / supositorio)'],
      codigoATC: 'N05BA01',
      familia: 'Benzodiacepinas (Vía Rectal en pacientes inconscientes)',
      formasYVias: [
        { id: 'rectal_diazepam', texto: 'Solución/enema o supositorio rectal (Vía Enteral Rectal)', via: 'Rectal', biodisponibilidad: 'Indicada en pacientes inconscientes, poco colaboradores o con vómitos recurrentes' }
      ],
      mecanismo: 'Anticonvulsivante y sedante administrado por vía rectal cuando la vía oral es inviable por inconsciencia.',
      ladme: 'Absorción más irregular que otras vías, pero salva la limitación de inconsciencia o vómitos sin requerir punción.',
      cuidadoEnfermero: 'Cuidar la intimidad del paciente (el temario destaca como inconvenientes que es incómoda, da vergüenza y tiene absorción irregular).',
      mnemotecnia: '«Paciente inconsciente sin vía canalizada o con vómitos: Diazepam por vía rectal.»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Pág. 32'
    },
    {
      id: 'farm_estradiol_fentanilo_parches',
      dci: 'Estradiol / Fentanilo',
      nombresTemario: ['Parches transdérmicos de Estradiol', 'Parches transdérmicos de Fentanilo'],
      codigoATC: 'G03CA03 / N02AB03',
      familia: 'Fármacos muy liposolubles en Parches Transdérmicos (Vía Tópica de Efecto Sistémico)',
      formasYVias: [
        { id: 'parche_liposoluble', texto: 'Parche o lámina con adhesivo sobre la piel (Vía Tópica Transdérmica)', via: 'Transdérmica', biodisponibilidad: 'Absorción lenta y prolongada por difusión hacia la circulación sistémica' }
      ],
      mecanismo: 'Requieren alta liposolubilidad para atravesar el estrato córneo y alcanzar el torrente sanguíneo sistémico de forma sostenida.',
      ladme: 'Forma farmacéutica compleja (requiere aprendizaje de uso).',
      cuidadoEnfermero: 'Rotar la zona de aplicación en la piel porque los parches pueden provocar irritación local (Pág. 38).',
      mnemotecnia: '«Parche transdérmico = fármaco muy liposoluble (Estradiol, Fentanilo, Nitroglicerina) con efecto sistémico.»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 12, 14, 36 y 38'
    },
    {
      id: 'farm_parenterales_insulina_heparina_adrenalina',
      dci: 'Insulina / Heparina / Adrenalina',
      nombresTemario: ['Insulina (SC)', 'Heparina en jeringa precargada (SC)', 'Adrenalina intracardíaca'],
      codigoATC: 'A10A / B01AB / C01CA24',
      familia: 'Fármacos de Vía Parenteral (Subcutánea, Intramuscular, Intravenosa y Especiales)',
      formasYVias: [
        { id: 'sc_insulina_heparina', texto: 'Inyección en tejido subcutáneo o jeringa precargada de un solo uso (Vía Subcutánea SC)', via: 'Subcutánea', biodisponibilidad: 'Absorción desde los capilares del tejido subcutáneo (Insulina, Heparina, vacunas)' },
        { id: 'id_hipersensibilidad', texto: 'Inyección superficial en la dermis de volúmenes pequeños (Vía Intradérmica ID)', via: 'Intradérmica', biodisponibilidad: 'Local en dermis para pruebas de hipersensibilidad' },
        { id: 'im_musculo', texto: 'Inyección en músculo periférico: 2-3 mL (máximo 1 mL en deltoides y tríceps) (Vía IM)', via: 'Intramuscular', biodisponibilidad: 'Más rápida que ID y SC por la alta vascularización muscular' },
        { id: 'emergencia_nadi_intraosea', texto: 'Vías de emergencia sin acceso IV: Intralingual (línea de Nadi), Intraósea (tibia/húmero proximal), Intracardíaca (Adrenalina) y Endotraqueal', via: 'Parenteral Especial', biodisponibilidad: 'Vías médicas de rescate vital cuando es imposible canalizar una vía IV' }
      ],
      mecanismo: 'Aporte parenteral sorteando la barrera gastrointestinal.',
      ladme: 'En vía IV existen 3 modalidades (Pág. 48): 1) Infusión de grandes volúmenes (mantenimiento/reposición), 2) Infusión intermitente (en paralelo o conectada en Y), y 3) Bolo IV (dosis concentrada directa con jeringuilla).',
      cuidadoEnfermero: 'Respetar estrictamente el límite de 1 mL en deltoides y tríceps (2-3 mL en otros músculos) y puncionar lejos de hueso, vasos y nervios (Pág. 47).',
      mnemotecnia: '«ID = Dermis (Alergia) · SC = Subcutáneo (Insulina/Heparina) · IM = 2-3 mL (Deltoides y Tríceps solo 1 mL).»',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · Págs. 19, 46, 47, 48, 50 y 51'
    }
  ];

  var casosUnidad1 = [
    {
      id: 'caso_t2_etapa1_asma_urgencias',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso Oficial T2 (Etapa 1/4) · Crisis de Asma Bronquial en Urgencias',
      pacienteNombre: 'Carlos M. (Ingreso en Urgencias)',
      avatar: '😮‍💨',
      salaId: 'sala_urgencias',
      coordenadasCama: { x: 8.2, y: 7.2 },
      urgencia: 'Alta',
      constantes: 'Disnea intensa · Sibilancias · Diagnóstico: Crisis de asma bronquial',
      historiaClinica: 'Paciente con antecedentes de asma bronquial que acude a Urgencias por presentar intensa falta de aire. Se examina y se diagnostica crisis de asma bronquial. En el carro de medicación dispones de Salbutamol (jarabe) y Salbutamol (para nebulizador).',
      preguntaClinica: 'Selecciona la forma farmacéutica y la vía de administración adecuada para esta urgencia:',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 4. Un caso clínico (Pág. 52)',
      recompensaBase: 650,
      opciones: [
        {
          id: 'opt_salbutamol_nebulizador',
          texto: '💨 Salbutamol para nebulizador · Vía Tópica Inhalatoria (gotas líquidas dispersas en nube de gas)',
          nivel: 'optima',
          explicacion: '¡Exacto! En una crisis de asma bronquial se requiere acción inmediata. La vía inhalatoria con nebulizador deposita el broncodilatador directamente en los alvéolos y bronquios con absorción muy rápida.',
          mnemotecnia: '«En emergencias la vía oral NO sirve por su inicio lento: en crisis asmática, Salbutamol en nebulizador.»'
        },
        {
          id: 'opt_salbutamol_jarabe',
          texto: '🥄 Salbutamol en jarabe (solución concentrada de azúcares en agua) · Vía Enteral Oral',
          nivel: 'danina',
          explicacion: 'Error clínico grave en urgencias: como recalca la página 26 del Tema 2, la vía oral tiene un inicio de acción lento («¡Emergencias no!»). En una crisis de falta de aire intensa el paciente no puede esperar a la absorción digestiva.',
          mnemotecnia: '«Vía oral = inicio lento (¡Emergencias no!).»'
        }
      ]
    },
    {
      id: 'caso_t2_etapa2_asma_uci',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso Oficial T2 (Etapa 2/4) · Empeoramiento Asmático e Ingreso en UCI',
      pacienteNombre: 'Carlos M. (Ingreso en UCI)',
      avatar: '🛌',
      salaId: 'sala_urgencias',
      coordenadasCama: { x: 8.2, y: 7.2 },
      urgencia: 'Crítica',
      constantes: 'Hipoxemia refractaria · Ingreso en Unidad de Cuidados Intensivos (UCI)',
      historiaClinica: 'El paciente no mejora de su crisis asmática, empeora y se decide su ingreso inmediato en la UCI. Dispones de Hidrocortisona (crema) e Hidrocortisona (polvo para preparación inyectable extemporánea).',
      preguntaClinica: 'Selecciona la forma farmacéutica y la vía de administración que utilizarías en la UCI:',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 4. Un caso clínico (Pág. 53) y Viales (Pág. 8)',
      recompensaBase: 700,
      opciones: [
        {
          id: 'opt_hidrocortisona_inyectable',
          texto: '💉 Hidrocortisona en polvo para preparación inyectable extemporánea (Vial reconstituido) · Vía Parenteral IV',
          nivel: 'optima',
          explicacion: '¡Impecable! El vial contiene el corticoide en polvo seco o liofilizado que requiere añadir líquido estéril antes de administrarse (preparación extemporánea) por vía intravenosa para lograr un efecto antiinflamatorio sistémico inmediato en la UCI.',
          mnemotecnia: '«Vial = polvo seco o liofilizado que se reconstituye con líquido para vía parenteral.»'
        },
        {
          id: 'opt_hidrocortisona_crema',
          texto: '🧴 Hidrocortisona en crema · Vía Tópica Cutánea',
          nivel: 'danina',
          explicacion: 'Inaceptable en UCI: la crema cutánea busca una acción localizada en la piel (eccemas, prurito, piel seca) y jamás revertirá un estatus asmático crítico.',
          mnemotecnia: '«La crema es para eccemas y prurito en la piel; en la UCI se usa el vial inyectable.»'
        }
      ]
    },
    {
      id: 'caso_t2_etapa3_neumonia_vomitos',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso Oficial T2 (Etapa 3/4) · Neumonía Hospitalaria con Fiebre y Vómitos',
      pacienteNombre: 'Carlos M. (Neumonía Nosocomial)',
      avatar: '🤒',
      salaId: 'sala_urgencias',
      coordenadasCama: { x: 8.2, y: 7.2 },
      urgencia: 'Alta',
      constantes: 'Fiebre alta · Tos húmeda · Vómitos activos · Falta de aire',
      historiaClinica: 'Durante su ingreso, el paciente adquiere una neumonía hospitalaria y como consecuencia presenta fiebre, tos húmeda, vómitos y continúa con falta de aire. Dispones de Aspirina (comprimidos), Paracetamol (jarabe) y Metamizol (inyectable).',
      preguntaClinica: 'Selecciona la forma farmacéutica y la vía de administración que utilizarías:',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 4. Un caso clínico (Pág. 54)',
      recompensaBase: 700,
      opciones: [
        {
          id: 'opt_metamizol_inyectable',
          texto: '💉 Metamizol (inyectable en ampolla) · Vía Parenteral (IV / IM)',
          nivel: 'optima',
          explicacion: '¡Correcto! Al presentar vómitos activos, la vía oral está contraindicada porque el paciente expulsaría los comprimidos o el jarabe. La vía parenteral introduce el Metamizol directamente en sangre o tejido sin atravesar la mucosa digestiva.',
          mnemotecnia: '«Si hay vómitos activos, la vía oral fracasa: elige Metamizol inyectable por vía parenteral.»'
        },
        {
          id: 'opt_paracetamol_jarabe_t2',
          texto: '🥄 Paracetamol (jarabe) · Vía Enteral Oral',
          nivel: 'suboptima',
          explicacion: 'Aunque el Paracetamol es antipirético, uno de los inconvenientes clave de la vía oral (Pág. 26) es que fracasa ante náuseas y vómitos porque se expulsa antes de absorberse.',
          mnemotecnia: '«Jarabe por boca en paciente que vomita = dosis perdida.»'
        },
        {
          id: 'opt_aspirina_comp_t2',
          texto: '💊 Aspirina (comprimidos) · Vía Enteral Oral',
          nivel: 'suboptima',
          explicacion: 'Los comprimidos orales serán expulsados con el vómito y además irritan la mucosa gástrica.',
          mnemotecnia: '«Ni comprimidos ni jarabes por vía oral cuando el paciente tiene vómitos.»'
        }
      ]
    },
    {
      id: 'caso_t2_etapa4_alta_domiciliaria',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso Oficial T2 (Etapa 4/4) · Plan de Alta Hospitalaria y Adherencia',
      pacienteNombre: 'Carlos M. (Alta a Domicilio)',
      avatar: '🏠',
      salaId: 'sala_consulta_u1',
      coordenadasCama: { x: 8.5, y: 2.8 },
      urgencia: 'Media',
      constantes: 'Afebril · Sin vómitos · Eupneico · Listo para el alta a casa',
      historiaClinica: 'El paciente evoluciona satisfactoriamente y se decide darle el alta indicándole antimicrobianos, antipiréticos y antiasmáticos. Dispones de: antimicrobianos (inyectables vs cápsulas duras); antipiréticos (suspensión vs comprimidos); y antiasmáticos (inyectables vs polvo para inhalación).',
      preguntaClinica: '¿Qué combinación de formas farmacéuticas y vías seleccionas para que el paciente cumpla el tratamiento en su domicilio?',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 4. Un caso clínico (Pág. 55) y Adherencia (Pág. 5)',
      recompensaBase: 750,
      opciones: [
        {
          id: 'opt_alta_oral_inhalatoria',
          texto: '✅ Antimicrobiano en cápsulas duras (Vía Oral) + Antipirético en comprimidos o suspensión (Vía Oral) + Antiasmático en dispositivo de polvo seco para inhalación (Vía Inhalatoria)',
          nivel: 'optima',
          explicacion: '¡Sobresaliente! Al alta domiciliaria el paciente ya no tiene vómitos y necesita vías cómodas, seguras, no invasivas y que no requieran esterilidad ni personal sanitario (Pág. 26), garantizando así la adherencia terapéutica (Pág. 5).',
          mnemotecnia: '«En casa al alta: cápsulas y comprimidos por vía oral + polvo seco por vía inhalatoria.»'
        },
        {
          id: 'opt_alta_todo_inyectable',
          texto: '💉 Antimicrobianos inyectables (Vía Parenteral) + Antiasmáticos inyectables (Vía Parenteral) + Antipiréticos en comprimidos',
          nivel: 'danina',
          explicacion: 'Pésima elección al alta: la vía parenteral es invasiva, requiere esterilidad, tiene mayor coste y compromete la adherencia terapéutica en el domicilio cuando existen alternativas orales e inhalatorias eficaces.',
          mnemotecnia: '«No mandes inyectables a casa si el paciente ya tolera cápsulas orales e inhalador de polvo seco.»'
        }
      ]
    },
    {
      id: 'caso_t2_sonda_nasogastrica_triturar',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso Oficial T2 (Pág. 30) · Sonda Nasogástrica y Liberación Retardada',
      pacienteNombre: 'Paciente Cirugía Maxilofacial (SNG)',
      avatar: '🧑‍🦲',
      salaId: 'sala_consulta_u1',
      coordenadasCama: { x: 8.5, y: 2.8 },
      urgencia: 'Alta',
      constantes: 'Postoperatorio cirugía maxilofacial · Portador de Sonda Nasogástrica (SNG)',
      historiaClinica: 'A un paciente hospitalizado recién intervenido de una cirugía maxilofacial que lleva una sonda nasogástrica le acaban de pautar un fármaco en comprimido de liberación retardada. La enfermera que lo atiende decide triturar el comprimido en el mortero para poder administrarlo a través de la sonda.',
      preguntaClinica: '¿Es correcto el procedimiento de triturar un comprimido de liberación retardada o recubrimiento entérico para pasarlo por la SNG?',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 3.1 Vía nasogástrica: Un caso clínico (Págs. 11, 30 y 31)',
      recompensaBase: 700,
      opciones: [
        {
          id: 'opt_no_triturar_sng',
          texto: '🛑 INCORRECTO: Jamás se debe triturar un comprimido de liberación retardada (ni de cubierta entérica); se destruiría el sistema de liberación lenta causando sobredosis brusca o degradación gástrica',
          nivel: 'optima',
          explicacion: '¡Exacto! Los comprimidos de liberación retardada están modificados para liberar el principio activo lentamente (Pág. 11). Si se machacan en el mortero para la SNG, toda la dosis se absorbe de golpe (riesgo tóxico grave) y obstruye la sonda. Hay que solicitar una forma líquida (jarabe/solución/suspensión) o de liberación inmediata.',
          mnemotecnia: '«Liberación retardada o cubierta entérica: prohibido el mortero en la sonda nasogástrica.»'
        },
        {
          id: 'opt_si_triturar_sng',
          texto: '◆ CORRECTO: Cualquier comprimido sólido puede machacarse y diluirse en agua para pasar por la sonda nasogástrica',
          nivel: 'danina',
          explicacion: 'Error iatrogénico grave: machacar un comprimido de liberación retardada anula su tecnología farmacéutica y descarga toda la dosis acumulada de una sola vez en el paciente.',
          mnemotecnia: '«Machacar liberación retardada = descarga tóxica masiva.»'
        }
      ]
    },
    {
      id: 'caso_t2_limites_parenterales_im_id_sc',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso T2 · Profundidad y Volumen Máximo en Vías Parenterales (ID, SC, IM)',
      pacienteNombre: 'Elena G. (Sala de Vacunación e Inyectables)',
      avatar: '🧓',
      salaId: 'sala_recepcion',
      coordenadasCama: { x: 3.0, y: 4.1 },
      urgencia: 'Media',
      constantes: 'Administración de inyectables en planta · Verificación de técnica enfermera',
      historiaClinica: 'En la sala de enfermería debes administrar una prueba de hipersensibilidad, una dosis de Insulina/Heparina y un fármaco intramuscular en el músculo deltoides.',
      preguntaClinica: 'Según las páginas 46 y 47 del Tema 2, ¿cuál es la relación correcta entre vía parenteral, tejido, ejemplos y volumen máximo en deltoides/tríceps?',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 3.3 Vía parenteral: ID, SC e IM (Págs. 46 y 47)',
      recompensaBase: 650,
      opciones: [
        {
          id: 'opt_parenteral_exacta',
          texto: '✅ ID = Dermis (pruebas de hipersensibilidad) · SC = Tejido subcutáneo (Insulina, Heparina, vacunas) · IM = Músculo (admite 2-3 mL en general, pero deltoides y tríceps admiten HASTA 1 mL)',
          nivel: 'optima',
          explicacion: '¡Clavado al PDF! La vía IM es más rápida que la ID y la SC porque el músculo periférico está altamente vascularizado, y admite de 2 a 3 mL salvo en deltoides y tríceps, cuyo límite máximo es de 1 mL.',
          mnemotecnia: '«En glúteo/vasto 2-3 mL; en deltoides y tríceps tope de 1 mL.»'
        },
        {
          id: 'opt_deltoides_3ml',
          texto: '✖ Inyectar 3 mL por vía intramuscular en el deltoides y administrar la Insulina por vía intradérmica',
          nivel: 'danina',
          explicacion: 'Doble error: el deltoides y el tríceps solo admiten hasta 1 mL (3 mL producirían lesión tisular/nerviosa) y la insulina/heparina se administran en el tejido subcutáneo (SC), no en la dermis (ID).',
          mnemotecnia: '«Insulina y Heparina van a Subcutánea (SC); Deltoides máximo 1 mL.»'
        }
      ]
    },
    {
      id: 'caso_t2_vias_emergencia_nadi_intraosea',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso T2 · Vías Parenterales Especiales (Línea de Nadi, Intraósea e Intracardíaca)',
      pacienteNombre: 'Roberto V. (Colapso Vascular sin Vía IV)',
      avatar: '🧔',
      salaId: 'sala_urgencias',
      coordenadasCama: { x: 8.2, y: 7.2 },
      urgencia: 'Crítica',
      constantes: 'Shock grave · Imposibilidad de canalizar acceso venoso periférico (Vía IV)',
      historiaClinica: 'En una urgencia vital resulta imposible canalizar una vía intravenosa periférica con rapidez. El equipo médico valora las vías parenterales alternativas descritas en las páginas 50 y 51 del Tema 2.',
      preguntaClinica: '¿Qué definen exactamente la vía intralingual, la vía intraósea y la vía intracardíaca en tu temario?',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 3.3 Otras vías parenterales (Págs. 49, 50 y 51)',
      recompensaBase: 750,
      opciones: [
        {
          id: 'opt_vias_especiales_ok',
          texto: '🏥 Intralingual = punción en la línea de Nadi de la lengua · Intraósea = cavidad medular (tibia proximal y húmero proximal) · Intracardíaca = Adrenalina directa al corazón cuando no hay vía IV',
          nivel: 'optima',
          explicacion: '¡Dominio total! Estos tres datos anatómicos y farmacológicos (línea de Nadi en la lengua, tibia/húmero proximal en intraósea y adrenalina en intracardíaca) son preguntas literales de las diapositivas 50 y 51.',
          mnemotecnia: '«Lengua = Línea de Nadi · Hueso = Tibia y Húmero proximal · Corazón = Adrenalina.»'
        },
        {
          id: 'opt_vias_especiales_err',
          texto: '✖ La vía intraósea se canaliza en el fémur distal para inyectar contrastes radiológicos y quimioterapia regional',
          nivel: 'danina',
          explicacion: 'Confusión de conceptos: los contrastes radiológicos y la quimioterapia antineoplásica regional se administran por vía INTRAARTERIAL (Pág. 50), y los sitios habituales de la intraósea son la tibia proximal y el húmero proximal (Pág. 51).',
          mnemotecnia: '«Contrastes y quimio regional = Intraarterial · Médula ósea de urgencia = Tibia/Húmero proximal.»'
        }
      ]
    },
    {
      id: 'caso_t2_topica_local_vs_sistemica',
      temaId: 't2',
      unidad: 1,
      titulo: 'Caso T2 · Vía Tópica: Cuándo produce Efecto Local vs Efecto Sistémico',
      pacienteNombre: 'Lactante y Paciente Cardiópata (Consulta)',
      avatar: '👶',
      salaId: 'sala_farmacia',
      coordenadasCama: { x: 3.4, y: 7.8 },
      urgencia: 'Media',
      constantes: 'Lactante con eczema de pañal (piel inflamada y dañada) + Paciente con otitis',
      historiaClinica: 'En la consulta de enfermería revisas dos casos de vía tópica (Págs. 36 y 41): 1) Un bebé con el área del pañal inflamada y dañada al que se aplica crema con corticoide; y 2) Un paciente al que se van a instilar gotas óticas con antibiótico.',
      preguntaClinica: 'Según el Tema 2, ¿qué ocurre con la absorción en la piel dañada del bebé y qué condición exige la vía ótica?',
      fuente: 'TEMA 02. PRINCIPIOS DE ADMINISTRACIÓN DE FÁRMACOS · 3.2 Vía tópica y Vía ótica (Págs. 36 y 41)',
      recompensaBase: 650,
      opciones: [
        {
          id: 'opt_topica_exacta',
          texto: '🔬 La crema con corticoide sobre la piel inflamada y dañada del bebé produce EFECTO SISTÉMICO (igual que los parches de nitroglicerina), y la vía ótica logra efecto local SIEMPRE QUE LA MEMBRANA TIMPÁNICA NO ESTÉ PERFORADA',
          nivel: 'optima',
          explicacion: '¡Perfecto! La diapositiva 36 clasifica expresamente la crema de corticoide en el eczema de pañal del bebé como ejemplo de efecto SISTÉMICO de la vía tópica (por rotura de la barrera cutánea), y la diapositiva 41 advierte que en la vía ótica la membrana no debe estar perforada.',
          mnemotecnia: '«Piel dañada del bebé + corticoide = pasa a sangre (sistémico). Oído = vigilar que el tímpano NO esté perforado.»'
        },
        {
          id: 'opt_topica_solo_local',
          texto: '◆ Toda crema aplicada en la piel de un bebé tiene únicamente efecto local, y las gotas óticas pueden echarse aunque el tímpano esté perforado',
          nivel: 'danina',
          explicacion: 'Error peligroso: en piel inflamada y erosionada de lactante el corticoide se absorbe a circulación general, y administrar gotas óticas con membrana perforada puede causar ototoxicidad en oído medio/interno.',
          mnemotecnia: '«Con piel erosionada o tímpano perforado, la barrera local se ha roto.»'
        }
      ]
    }
  ];

  FT.datosUnidad1 = {
    farmacos: farmacosUnidad1,
    casos: casosUnidad1
  };

})(window.FT = window.FT || {});