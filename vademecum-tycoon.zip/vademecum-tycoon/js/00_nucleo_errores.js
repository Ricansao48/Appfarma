/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/00_nucleo_errores.js
   Responsabilidad: Espacio de nombres global (window.FT), utilidades puras,
   generador pseudoaleatorio con semilla y capturador global de errores con
   botón "Copiar informe" para depuración entre chats.
   ========================================================================== */

(function (FT) {
  'use strict';

  FT.NOMBRE_JUEGO = 'Vademécum Tycoon: Dirección Clínica';
  FT.VERSION_CODIGO = '0.1.0-fase1.1';

  /* ------------------------------------------------------------------------
     1. UTILIDADES MATEMÁTICAS, FORMATO Y GENERADOR DETERMINISTA (PRNG)
     ------------------------------------------------------------------------ */
  FT.util = {
    clamp: function (valor, min, max) {
      return Math.max(min, Math.min(max, valor));
    },

    clonarProfundo: function (objeto) {
      return JSON.parse(JSON.stringify(objeto));
    },

    generarId: function (prefijo) {
      var azar = Math.random().toString(36).substring(2, 8);
      return (prefijo || 'id') + '_' + Date.now().toString(36) + '_' + azar;
    },

    formatearMoneda: function (cantidad) {
      var numero = Number(cantidad) || 0;
      return numero.toLocaleString('es-ES') + ' €';
    },

    formatearHoraMinutos: function (minutosTotalesDia) {
      var min = Math.floor(minutosTotalesDia % 1440);
      var horas = Math.floor(min / 60);
      var restoMin = min % 60;
      var hStr = horas < 10 ? '0' + horas : String(horas);
      var mStr = restoMin < 10 ? '0' + restoMin : String(restoMin);
      return hStr + ':' + mStr;
    },

    escaparHtml: function (texto) {
      if (texto === null || texto === undefined) return '';
      return String(texto)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    },

    crearPRNG: function (semillaInicial) {
      var estado = (Number(semillaInicial) || 123456789) >>> 0;
      return {
        siguienteFloat: function () {
          estado = (1664525 * estado + 1013904223) >>> 0;
          return estado / 4294967296;
        },
        enteroEntre: function (min, max) {
          var f = this.siguienteFloat();
          return Math.floor(min + f * (max - min + 1));
        },
        elegirElemento: function (lista) {
          if (!Array.isArray(lista) || lista.length === 0) return null;
          return lista[this.enteroEntre(0, lista.length - 1)];
        }
      };
    },

    mostrarToast: function (mensaje, tipo) {
      var contenedor = document.getElementById('contenedor-toasts');
      if (!contenedor) return;

      var toast = document.createElement('div');
      toast.className = 'toast-item';
      if (tipo === 'error') {
        toast.style.borderLeftColor = 'var(--color-danina)';
      } else if (tipo === 'aviso') {
        toast.style.borderLeftColor = 'var(--color-aceptable)';
      }
      toast.textContent = mensaje;
      contenedor.appendChild(toast);

      setTimeout(function () {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 3400);
    }
  };

  /* ------------------------------------------------------------------------
     2. CAPTURADOR GLOBAL DE ERRORES CON INFORME COPIABLE
     ------------------------------------------------------------------------ */
  var historialErrores = [];

  function extraerNombreArchivo(urlCompleta) {
    if (!urlCompleta) return 'archivo_desconocido';
    var partes = String(urlCompleta).split('/');
    return partes[partes.length - 1] || urlCompleta;
  }

  function renderizarPanelErrores() {
    var panel = document.getElementById('panel-capturador-errores');
    var pre = document.getElementById('lista-errores-capturados');
    if (!panel || !pre) return;

    if (historialErrores.length === 0) {
      panel.classList.add('oculto');
      return;
    }

    panel.classList.remove('oculto');
    var lineas = historialErrores.map(function (err, idx) {
      return (
        '[' + (idx + 1) + '] ' + err.fecha + '\n' +
        'Mensaje: ' + err.mensaje + '\n' +
        'Ubicación: ' + err.archivo + ':' + err.linea + ':' + err.columna + '\n' +
        (err.pila ? 'Pila: ' + err.pila : '')
      );
    });
    pre.textContent = lineas.join('\n----------------------------------------\n');
  }

  function registrarError(mensaje, archivo, linea, columna, errorObj) {
    var registro = {
      fecha: new Date().toLocaleTimeString('es-ES'),
      mensaje: String(mensaje || 'Error sin mensaje'),
      archivo: extraerNombreArchivo(archivo),
      linea: linea || 0,
      columna: columna || 0,
      pila: errorObj && errorObj.stack ? String(errorObj.stack).split('\n').slice(0, 4).join(' | ') : ''
    };
    historialErrores.push(registro);
    renderizarPanelErrores();
  }

  window.onerror = function (mensaje, url, linea, columna, errorObj) {
    registrarError(mensaje, url, linea, columna, errorObj);
    return false;
  };

  window.addEventListener('unhandledrejection', function (evento) {
    var razon = evento.reason ? (evento.reason.message || String(evento.reason)) : 'Promesa rechazada';
    registrarError('Promesa no controlada: ' + razon, 'async', 0, 0, evento.reason);
  });

  FT.errores = {
    obtenerHistorial: function () {
      return historialErrores.slice();
    },

    registrarManual: function (mensaje, contextoArchivo) {
      registrarError(mensaje, contextoArchivo || 'manual', 0, 0, null);
    },

    simularErrorPrueba: function () {
      try {
        throw new Error('Simulación de prueba: fallo controlado en bomba de perfusión IV.');
      } catch (err) {
        registrarError(err.message, 'js/00_nucleo_errores.js', 132, 15, err);
        FT.util.mostrarToast('Error de prueba capturado correctamente.', 'error');
      }
    },

    limpiarErrores: function () {
      historialErrores = [];
      renderizarPanelErrores();
    },

    generarInformeTexto: function () {
      var encabezado =
        '=== INFORME DE DEPURACIÓN · VADEMÉCUM TYCOON ===\n' +
        'Versión: ' + FT.VERSION_CODIGO + '\n' +
        'Navegador: ' + navigator.userAgent + '\n' +
        'Total errores: ' + historialErrores.length + '\n\n';
      var cuerpo = historialErrores.map(function (e, i) {
        return (
          '#' + (i + 1) + ' [' + e.fecha + '] ' + e.archivo + ':' + e.linea + ':' + e.columna + '\n' +
          '   ' + e.mensaje + '\n' +
          (e.pila ? '   ' + e.pila + '\n' : '')
        );
      }).join('\n');
      return encabezado + cuerpo;
    },

    copiarInformeAlPortapapeles: function () {
      var informe = this.generarInformeTexto();
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(informe).then(function () {
          FT.util.mostrarToast('Informe de error copiado al portapapeles.');
        }).catch(function () {
          FT.util.mostrarToast('No se pudo usar clipboard automático; selecciona el texto manualmente.', 'aviso');
        });
      } else {
        FT.util.mostrarToast('Selecciona el texto del recuadro para copiarlo.', 'aviso');
      }
    }
  };

  document.addEventListener('DOMContentLoaded', function () {
    var btnCopiar = document.getElementById('btn-copiar-informe-error');
    var btnOcultar = document.getElementById('btn-ocultar-panel-error');
    if (btnCopiar) {
      btnCopiar.addEventListener('click', function () {
        FT.errores.copiarInformeAlPortapapeles();
      });
    }
    if (btnOcultar) {
      btnOcultar.addEventListener('click', function () {
        var panel = document.getElementById('panel-capturador-errores');
        if (panel) panel.classList.add('oculto');
      });
    }
  });

})(window.FT = window.FT || {});