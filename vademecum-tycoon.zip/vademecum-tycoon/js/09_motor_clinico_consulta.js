/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/09_motor_clinico_consulta.js
   Responsabilidad: Gestión de la cola de casos clínicos de la Unidad 1,
   checklist de los 5 Correctos de Enfermería, delegación automática por
   dominio, buscador del Vademécum y conexión con las animaciones 3D.
   ========================================================================== */

(function (FT) {
  'use strict';

  var indiceCasoActual = 0;
  var cincoCorrectosMarcados = {
    paciente: true,
    farmaco: true,
    dosis: true,
    via: true,
    hora: true
  };

  function obtenerCasos() {
    return (FT.datosUnidad1 && FT.datosUnidad1.casos) ? FT.datosUnidad1.casos : [];
  }

  function obtenerFarmacos() {
    return (FT.datosUnidad1 && FT.datosUnidad1.farmacos) ? FT.datosUnidad1.farmacos : [];
  }

  function actualizarContadorBotonConsulta() {
    var btn = document.getElementById('btn-dock-consulta');
    var casos = obtenerCasos();
    if (btn && casos.length > 0) {
      var caso = casos[indiceCasoActual % casos.length];
      btn.textContent = '🩺 Consulta (' + (indiceCasoActual + 1) + '/' + casos.length + ': ' + caso.temaId.toUpperCase() + ')';
    }
  }

  /* ------------------------------------------------------------------------
     1. RENDERIZADO DEL PANEL DE CONSULTA CLÍNICA + 5 CORRECTOS
     ------------------------------------------------------------------------ */
  function abrirPanelConsultaCasoActual(casoForzadoId) {
    var casos = obtenerCasos();
    if (!casos.length) return;

    if (casoForzadoId) {
      for (var i = 0; i < casos.length; i++) {
        if (casos[i].id === casoForzadoId) {
          indiceCasoActual = i;
          break;
        }
      }
    }

    var caso = casos[indiceCasoActual % casos.length];
    var panel = document.getElementById('panel-clinico-derecho');
    var titulo = document.getElementById('titulo-panel-derecho');
    var cuerpo = document.getElementById('contenedor-muestra-farmacos');
    if (!panel || !cuerpo) return;

    panel.classList.remove('panel-plegado');
    if (titulo) {
      titulo.textContent = '🩺 Historia Clínica · Unidad 1 (' + caso.temaId.toUpperCase() + ')';
    }

    var est = FT.estado ? FT.estado.obtener() : null;
    var modoEstudio = est && est.meta && est.meta.modoJuego === 'estudio';
    var dominioTema = (est && est.progreso && est.progreso.temas[caso.temaId])
      ? est.progreso.temas[caso.temaId].dominio
      : 0;

    var htmlOpciones = caso.opciones.map(function (op) {
      return (
        '<button type="button" class="btn btn-secundario" style="justify-content:flex-start;text-align:left;width:100%;white-space:normal;line-height:1.35;padding:0.65rem 0.8rem" data-opcion-id="' + op.id + '">' +
          op.texto +
        '</button>'
      );
    }).join('');

    var htmlDelegacion = '';
    if (dominioTema >= 75) {
      htmlDelegacion =
        '<button type="button" id="btn-delegar-enfermero" class="btn btn-exito btn-sm" style="width:100%">' +
          '🤖 Delegar en Enfermero Marcos (Dominio ' + caso.temaId.toUpperCase() + ': ' + dominioTema + '% · Plata/Oro)' +
        '</button>';
    } else {
      htmlDelegacion =
        '<div class="texto-secundario" style="font-size:0.74rem;background:#F1F5F9;padding:0.4rem 0.6rem;border-radius:6px">' +
          '🔒 <strong>Delegación enfermera:</strong> Alcanza <strong>75% de dominio</strong> en ' + caso.temaId.toUpperCase() + ' (actual: <strong>' + dominioTema + '%</strong>) para que el personal resuelva estos casos automáticamente.' +
        '</div>';
    }

    cuerpo.innerHTML =
      /* Navegador rápido de los 6 casos de la Unidad 1 */
      '<div style="display:flex;align-items:center;justify-content:space-between;gap:0.4rem">' +
        '<button type="button" id="btn-caso-anterior" class="btn btn-secundario btn-xs">◀ Anterior</button>' +
        '<span class="badge badge-info">Caso ' + (indiceCasoActual + 1) + ' de ' + casos.length + ' · ' + caso.temaId.toUpperCase() + '</span>' +
        '<button type="button" id="btn-caso-siguiente" class="btn btn-secundario btn-xs">Siguiente ▶</button>' +
      '</div>' +

      /* Tarjeta clínica del paciente */
      '<div class="ficha-farmaco-cromo" style="border-left:5px solid var(--color-primario)">' +
        '<div class="ficha-farmaco-titulo">' +
          '<h3>' + caso.avatar + ' ' + caso.pacienteNombre + '</h3>' +
          '<span class="badge badge-danino">Urgencia ' + caso.urgencia + '</span>' +
        '</div>' +
        '<p class="texto-secundario" style="font-weight:700;color:var(--color-primario)">' + caso.titulo + '</p>' +
        '<p class="texto-secundario"><strong>📊 Constantes:</strong> ' + caso.constantes + '</p>' +
        '<p class="texto-secundario">' + caso.historiaClinica + '</p>' +
        '<div class="ficha-ref-trazabilidad">📌 ' + caso.fuente + '</div>' +
      '</div>' +

      /* Checklist interactivo de los 5 Correctos de Enfermería */
      '<div class="ficha-farmaco-cromo" style="background:#F8FAFC;padding:0.65rem">' +
        '<strong style="font-size:0.78rem;color:var(--color-texto-principal)">🛡️ Verificación Enfermera (Los 5 Correctos):</strong>' +
        '<div style="display:flex;flex-wrap:wrap;gap:0.45rem;margin-top:0.3rem;font-size:0.75rem">' +
          '<label style="display:flex;align-items:center;gap:0.2rem;cursor:pointer"><input type="checkbox" class="chk-5c" data-c="paciente" checked> 1. Paciente</label>' +
          '<label style="display:flex;align-items:center;gap:0.2rem;cursor:pointer"><input type="checkbox" class="chk-5c" data-c="farmaco" checked> 2. Fármaco</label>' +
          '<label style="display:flex;align-items:center;gap:0.2rem;cursor:pointer"><input type="checkbox" class="chk-5c" data-c="dosis" checked> 3. Dosis</label>' +
          '<label style="display:flex;align-items:center;gap:0.2rem;cursor:pointer"><input type="checkbox" class="chk-5c" data-c="via" checked> 4. Vía</label>' +
          '<label style="display:flex;align-items:center;gap:0.2rem;cursor:pointer"><input type="checkbox" class="chk-5c" data-c="hora" checked> 5. Hora</label>' +
        '</div>' +
      '</div>' +

      htmlDelegacion +

      '<h3 style="font-size:0.88rem;margin-top:0.2rem">' + caso.preguntaClinica + '</h3>' +
      (modoEstudio ? '<button type="button" id="btn-pista-carmen" class="btn btn-fantasma btn-xs">💡 Ver pista de la Supervisora Carmen (Modo Estudio)</button>' : '') +

      '<div style="display:flex;flex-direction:column;gap:0.45rem">' +
        htmlOpciones +
      '</div>' +

      '<div id="caja-feedback-consulta"></div>';

    /* Eventos de navegación entre casos */
    document.getElementById('btn-caso-anterior').addEventListener('click', function () {
      indiceCasoActual = (indiceCasoActual - 1 + casos.length) % casos.length;
      if (FT.audio) FT.audio.tocarClick();
      actualizarContadorBotonConsulta();
      abrirPanelConsultaCasoActual();
    });

    document.getElementById('btn-caso-siguiente').addEventListener('click', function () {
      indiceCasoActual = (indiceCasoActual + 1) % casos.length;
      if (FT.audio) FT.audio.tocarClick();
      actualizarContadorBotonConsulta();
      abrirPanelConsultaCasoActual();
    });

    /* Botón de delegación si ya domina el tema */
    var btnDelegar = document.getElementById('btn-delegar-enfermero');
    if (btnDelegar) {
      btnDelegar.addEventListener('click', function () {
        var optOptima = caso.opciones.filter(function (o) { return o.nivel === 'optima'; })[0] || caso.opciones[0];
        evaluarOpcionClinica(caso, optOptima, true);
      });
    }

    /* Botón de pista en Modo Estudio */
    var btnPista = document.getElementById('btn-pista-carmen');
    if (btnPista) {
      btnPista.addEventListener('click', function () {
        var optOptima = caso.opciones.filter(function (o) { return o.nivel === 'optima'; })[0];
        if (optOptima) {
          FT.util.mostrarToast('💡 Carmen: ' + optOptima.mnemotecnia);
        }
      });
    }

    /* Eventos de las opciones de prescripción */
    cuerpo.querySelectorAll('[data-opcion-id]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var idOp = btn.getAttribute('data-opcion-id');
        var opcion = caso.opciones.filter(function (o) { return o.id === idOp; })[0];
        if (opcion) {
          evaluarOpcionClinica(caso, opcion, false);
        }
      });
    });

    actualizarContadorBotonConsulta();
  }

  /* ------------------------------------------------------------------------
     2. EVALUACIÓN CLÍNICA (4 NIVELES + DISPARO DE RUTA 3D DEL ENFERMERO)
     ------------------------------------------------------------------------ */
  function evaluarOpcionClinica(caso, opcion, fueDelegado) {
    var caja = document.getElementById('caja-feedback-consulta');
    if (!caja) return;

    /* Verificar que los 5 Correctos estén marcados */
    var checks = document.querySelectorAll('.chk-5c');
    var todosMarcados = true;
    checks.forEach(function (c) {
      if (!c.checked) todosMarcados = false;
    });

    if (!todosMarcados && !fueDelegado) {
      if (FT.audio) FT.audio.tocarAlertaRAM();
      caja.innerHTML =
        '<div class="alerta-evaluacion nivel-danina">' +
          '<span class="icono-nivel">✖</span>' +
          '<div>' +
            '<strong>ALERTA DE SEGURIDAD ENFERMERA: Faltan casillas de los 5 Correctos</strong>' +
            '<p>Has dejado sin verificar alguno de los 5 Correctos (Paciente, Fármaco, Dosis, Vía u Hora). Marca los 5 antes de administrar.</p>' +
          '</div>' +
        '</div>';
      return;
    }

    var est = FT.estado.obtener();
    var esModoEstudio = est.meta.modoJuego === 'estudio';
    var dineroDelta = 0;
    var repDelta = 0;
    var dominioDelta = 0;
    var icono = '✓';
    var tituloNivel = '';

    if (opcion.nivel === 'optima') {
      dineroDelta = fueDelegado ? Math.round(caso.recompensaBase * 0.85) : caso.recompensaBase;
      repDelta = 25;
      dominioDelta = 30;
      icono = '✓';
      tituloNivel = fueDelegado
        ? 'DELEGACIÓN ENFERMERA ÓPTIMA (85% ingreso · +' + dineroDelta + ' €)'
        : 'DECISIÓN ÓPTIMA (100% · +' + dineroDelta + ' € y +30% Dominio ' + caso.temaId.toUpperCase() + ')';
      if (FT.audio) FT.audio.tocarExitoMonedas();
    } else if (opcion.nivel === 'aceptable') {
      dineroDelta = Math.round(caso.recompensaBase * 0.65);
      repDelta = 10;
      dominioDelta = 15;
      icono = '▲';
      tituloNivel = 'DECISIÓN ACEPTABLE (70% · +' + dineroDelta + ' €)';
      if (FT.audio) FT.audio.tocarSeleccion();
    } else if (opcion.nivel === 'suboptima') {
      dineroDelta = Math.round(caso.recompensaBase * 0.25);
      repDelta = esModoEstudio ? 0 : -5;
      dominioDelta = 5;
      icono = '◆';
      tituloNivel = 'DECISIÓN SUBÓPTIMA / VÍA INEFICAZ (25% · +' + dineroDelta + ' €)';
      if (FT.audio) FT.audio.tocarAlertaRAM();
    } else {
      dineroDelta = esModoEstudio ? 0 : -350;
      repDelta = esModoEstudio ? 0 : -20;
      dominioDelta = 0;
      icono = '✖';
      tituloNivel = esModoEstudio
        ? 'DECISIÓN DAÑINA / IATROGÉNICA (Sin multa en Modo Estudio)'
        : 'DECISIÓN DAÑINA / IATROGÉNICA (' + dineroDelta + ' € por evento adverso)';
      if (FT.audio) FT.audio.tocarAlertaRAM();
    }

    FT.estado.modificarDinero(dineroDelta, caso.titulo);
    FT.estado.modificarReputacion(repDelta, caso.titulo);
    if (dominioDelta > 0) {
      FT.estado.registrarProgresoTema(caso.temaId, dominioDelta);
    }
    FT.estado.avanzarTiempoMinutos(35);

    /* Ordenar al motor 3D isométrico que el enfermero vaya a Farmacia y atienda al paciente */
    if (FT.render && FT.render.ejecutarRondaEnfermeria3D) {
      FT.render.ejecutarRondaEnfermeria3D(
        caso.coordenadasCama.x,
        caso.coordenadasCama.y,
        opcion.nivel,
        (dineroDelta >= 0 ? '+' : '') + dineroDelta + ' €'
      );
    }

    caja.innerHTML =
      '<div class="alerta-evaluacion nivel-' + opcion.nivel + '" style="margin-top:0.4rem">' +
        '<span class="icono-nivel">' + icono + '</span>' +
        '<div>' +
          '<strong>' + tituloNivel + '</strong>' +
          '<p style="margin-top:0.25rem">' + opcion.explicacion + '</p>' +
          '<p style="margin-top:0.3rem"><strong>💡 Regla de Oro (Carmen):</strong> <em>' + opcion.mnemotecnia + '</em></p>' +
          '<div class="ficha-ref-trazabilidad" style="margin-top:0.35rem">📚 ' + caso.fuente + '</div>' +
          '<button type="button" id="btn-pasar-siguiente-caso" class="btn btn-primario btn-xs" style="margin-top:0.55rem">' +
            '▶ Atender Siguiente Paciente de la Guardia' +
          '</button>' +
        '</div>' +
      '</div>';

    var btnSig = document.getElementById('btn-pasar-siguiente-caso');
    if (btnSig) {
      btnSig.addEventListener('click', function () {
        var total = obtenerCasos().length;
        indiceCasoActual = (indiceCasoActual + 1) % total;
        actualizarContadorBotonConsulta();
        abrirPanelConsultaCasoActual();
      });
    }
  }

  /* ------------------------------------------------------------------------
     3. VADEMÉCUM INTERACTIVO CON FILTRO DE BÚSQUEDA (CROMOS UNIDAD 1)
     ------------------------------------------------------------------------ */
  function abrirVademecumUnidad1() {
    var panel = document.getElementById('panel-clinico-derecho');
    var titulo = document.getElementById('titulo-panel-derecho');
    var cuerpo = document.getElementById('contenedor-muestra-farmacos');
    if (!panel || !cuerpo) return;

    panel.classList.remove('panel-plegado');
    if (titulo) titulo.textContent = '📖 Vademécum Oficial · Unidad 1 (6 Fichas)';

    cuerpo.innerHTML =
      '<input type="search" id="buscador-vademecum-u1" placeholder="🔎 Buscar por DCI, ATC (N02BA01), vía, LADME..." ' +
        'style="width:100%;padding:0.55rem 0.75rem;border:1px solid var(--color-borde);border-radius:8px;font-size:0.85rem">' +
      '<div id="lista-cromos-vademecum" style="display:flex;flex-direction:column;gap:0.75rem"></div>';

    var input = document.getElementById('buscador-vademecum-u1');
    var contenedorLista = document.getElementById('lista-cromos-vademecum');

    function pintarLista(filtro) {
      var q = (filtro || '').toLowerCase().trim();
      var farmacos = obtenerFarmacos().filter(function (f) {
        if (!q) return true;
        var blob = (f.dci + ' ' + f.nombresTemario.join(' ') + ' ' + f.codigoATC + ' ' + f.familia + ' ' + f.mecanismo + ' ' + f.ladme).toLowerCase();
        return blob.indexOf(q) !== -1;
      });

      contenedorLista.innerHTML = farmacos.map(function (f) {
        var viasTxt = f.formasYVias.map(function (v) { return v.texto; }).join(' · ');
        return (
          '<article class="ficha-farmaco-cromo">' +
            '<div class="ficha-farmaco-titulo">' +
              '<h3>' + f.dci + '</h3>' +
              '<span class="badge badge-atc">ATC: ' + f.codigoATC + '</span>' +
            '</div>' +
            '<p class="texto-secundario"><strong>En temario:</strong> ' + f.nombresTemario.join(', ') + '</p>' +
            '<p class="texto-secundario"><strong>Familia:</strong> ' + f.familia + '</p>' +
            '<p class="texto-secundario"><strong>Formas y vías:</strong> ' + viasTxt + '</p>' +
            '<p class="texto-secundario"><strong>Farmacocinética (LADME):</strong> ' + f.ladme + '</p>' +
            '<p class="texto-secundario"><strong>Cuidado enfermero:</strong> ' + f.cuidadoEnfermero + '</p>' +
            '<div class="ficha-mnemotecnia">💡 <strong>Carmen:</strong> ' + f.mnemotecnia + '</div>' +
            '<div class="ficha-ref-trazabilidad">📌 ' + f.fuente + '</div>' +
          '</article>'
        );
      }).join('');
    }

    pintarLista('');
    input.addEventListener('input', function () {
      pintarLista(input.value);
    });
  }

  FT.clinica = {
    abrirConsulta: abrirPanelConsultaCasoActual,
    abrirVademecum: abrirVademecumUnidad1,
    actualizarBoton: actualizarContadorBotonConsulta
  };

})(window.FT = window.FT || {});