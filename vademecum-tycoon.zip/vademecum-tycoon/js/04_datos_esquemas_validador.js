/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/04_datos_esquemas_validador.js
   Responsabilidad: Registro de datos farmacológicos, semilla verificada de la
   Unidad 1 (Temas 1 y 2), validador automático de integridad y controlador
   interactivo del banco de pruebas de la Fase 1.1.
   ========================================================================== */

(function (FT) {
  'use strict';

  /* ------------------------------------------------------------------------
     1. SEMILLA DE CONOCIMIENTO DE UNIDAD 1 (TRAZABLE AL TEMARIO ADJUNTO)
     ------------------------------------------------------------------------ */
  FT.datos = {
    unidades: {
      u1: {
        id: 'u1',
        titulo: 'Unidad 1: Farmacología General',
        departamentoId: 'D1',
        temas: ['t1', 't2', 't3', 't4'],
        ref: { archivo: 'TEMA 01-04', unidad: 'Unidad 1', seccion: 'Índice de Bloque', pagina: 2 }
      }
    },

    temas: {
      t1: {
        id: 't1',
        unidadId: 'u1',
        numero: 1,
        titulo: 'Tema 1: Introducción a la Farmacología',
        autores: ['D. Asdrúbal Ferre Alcaide', 'Dña. Amparo Buaki', 'Dra. Eugenia García Zaragozá'],
        ref: { archivo: 'TEMA 01. INTRODUCCION A LA FARMACOLOGIA.pdf', unidad: 'Unidad 1', seccion: 'Portada e Índice', pagina: 1 }
      },
      t2: {
        id: 't2',
        unidadId: 'u1',
        numero: 2,
        titulo: 'Tema 2: Principios de administración de fármacos',
        autores: ['Dra. Eugenia García Zaragozá'],
        ref: { archivo: 'TEMA 02. PRINCIPIOS DE ADMINISTRACION DE FARMACOS.pdf', unidad: 'Unidad 1', seccion: 'Portada', pagina: 1 }
      }
    },

    farmacos: {
      f_paracetamol: {
        id: 'f_paracetamol',
        dci: 'Paracetamol',
        nombresTemario: ['Paracetamol STADAGEN 1 g EFG', 'Efferalgan®', 'Anadin®'],
        codigoATC: null,
        unidadId: 'u1',
        temaId: 't1',
        familia: 'Analgésicos y antipiréticos',
        mecanismo: {
          resumen: 'Fármaco analgésico y antipirético de referencia en especialidades genéricas (EFG) y publicitarias.',
          diana: 'Inhibición central de la síntesis de prostaglandinas'
        },
        formasVias: [
          { via: 'oral', forma: 'Comprimidos efervescentes 1 g (EFG) / Jarabe', aptoEnVomitos: false }
        ],
        indicaciones: ['ind_fiebre', 'ind_dolor_leve_moderado'],
        contraindicaciones: ['ci_insuficiencia_hepatica_grave'],
        reaccionesAdversas: ['ram_hepatotoxicidad_sobredosis'],
        cuidadosEnfermeria: [
          'En pacientes con HTA o cardiopatía que requieren analgesia, valorar Paracetamol frente a AINEs con el médico.',
          'No administrar por vía oral (jarabe/comprimidos) si el paciente presenta vómitos activos.'
        ],
        mnemotecnia: 'Si hay HTA o cardiopatía en la historia, el Paracetamol se lleva la victoria (y si vomita, la vía oral se evita).',
        ref: {
          archivo: 'TEMA 01 / TEMA 11 (farma)',
          unidad: 'Unidad 1 y Unidad 2',
          tema: 'Tema 1 (EFG Stadagen 1 g) y Tema 11 (Ejemplos de utilización)',
          seccion: 'Especialidades farmacéuticas genéricas / Caso clínico Tema 2',
          pagina: 10
        }
      },

      f_acido_acetilsalicilico: {
        id: 'f_acido_acetilsalicilico',
        dci: 'Ácido acetilsalicílico',
        nombresTemario: ['Aspirina®'],
        codigoATC: 'N02BA01',
        unidadId: 'u1',
        temaId: 't1',
        familia: 'Derivados del ácido salicílico (Analgésicos y antipiréticos)',
        mecanismo: {
          resumen: 'Analgésico, antipirético y antiinflamatorio derivado del ácido salicílico (clasificación ATC N02BA01).',
          diana: 'Inhibición de la ciclooxigenasa (COX)'
        },
        formasVias: [
          { via: 'oral', forma: 'Comprimidos', aptoEnVomitos: false }
        ],
        indicaciones: ['ind_fiebre', 'ind_dolor_leve_moderado'],
        contraindicaciones: ['ci_ulcera_peptica', 'ci_alergia_salicilatos'],
        reaccionesAdversas: ['ram_irritacion_gastrica'],
        cuidadosEnfermeria: [
          'Código ATC de estudio obligatorio en Tema 1: N (Sistema nervioso) 02 (Analgésicos) B (Analgésicos y antipiréticos) A (Derivados del ácido salicílico) 01 (Ácido acetilsalicílico).',
          'En comprimidos orales no es útil si el paciente presenta vómitos.'
        ],
        mnemotecnia: 'N02BA01: Nervioso (N), 02 Analgésico, B Antipirético, A Salicílico, 01 Aspirina.',
        ref: {
          archivo: 'TEMA 01. INTRODUCCION A LA FARMACOLOGIA.pdf',
          unidad: 'Unidad 1',
          tema: 'Tema 1: Clasificación de los fármacos (ATC)',
          seccion: 'Desglose de 5 niveles de N02BA01: Aspirina®',
          pagina: 14
        }
      },

      f_metamizol: {
        id: 'f_metamizol',
        dci: 'Metamizol',
        nombresTemario: ['Metamizol (inyectable)'],
        codigoATC: null,
        unidadId: 'u1',
        temaId: 't2',
        familia: 'Analgésicos y antipiréticos (Pirazolonas)',
        mecanismo: {
          resumen: 'Analgésico y antipirético administrable en solución inyectable por vía parenteral.',
          diana: 'Inhibición de síntesis de prostaglandinas'
        },
        formasVias: [
          { via: 'parenteral', forma: 'Ampolla inyectable (solución estéril para vía parenteral)', aptoEnVomitos: true }
        ],
        indicaciones: ['ind_fiebre', 'ind_dolor_agudo'],
        contraindicaciones: ['ci_alergia_pirazolonas'],
        reaccionesAdversas: ['ram_hipotension_iv_rapida'],
        cuidadosEnfermeria: [
          'De elección en el caso clínico del Tema 2 para bajar la fiebre en paciente con neumonía y vómitos activos (vía parenteral).'
        ],
        mnemotecnia: 'Ante fiebre alta y vómito sin control, vía parenteral con ampolla de Metamizol.',
        ref: {
          archivo: 'TEMA 02. PRINCIPIOS DE ADMINISTRACION DE FARMACOS.pdf',
          unidad: 'Unidad 1',
          tema: 'Tema 2: Principios de administración de fármacos',
          seccion: 'Formas líquidas parenterales (Ampollas) y Caso clínico de neumonía con vómitos',
          pagina: 28
        }
      }
    },

    patologias: {
      pat_neumonia_vomitos_t2: {
        id: 'pat_neumonia_vomitos_t2',
        titulo: 'Neumonía con fiebre alta y vómitos activos',
        unidadId: 'u1',
        temaId: 't2',
        departamentoId: 'D1',
        sintomas: ['Fiebre alta (39,2 °C)', 'Tos y disnea', 'Vómitos activos (intolerancia oral)'],
        objetivo: 'Seleccionar el fármaco antipirético y la forma/vía de administración eficaz ante la presencia de vómitos.',
        solucionOptima: {
          farmacoId: 'f_metamizol',
          via: 'parenteral',
          justificacion: 'El paciente presenta vómitos, por lo que las formas orales (Aspirina en comprimidos o Paracetamol en jarabe) se expulsan o no se absorben adecuadamente. El Metamizol en inyectable parenteral es la opción óptima del caso clínico.'
        },
        ref: {
          archivo: 'TEMA 02. PRINCIPIOS DE ADMINISTRACION DE FARMACOS.pdf',
          unidad: 'Unidad 1',
          tema: 'Tema 2: Principios de administración de fármacos',
          seccion: '4. Un caso clínico (Neumonía con fiebre, disnea y vómitos)',
          pagina: 28
        }
      }
    }
  };

  /* ------------------------------------------------------------------------
     2. VALIDADOR AUTOMÁTICO DE INTEGRIDAD DEL CONTENIDO (FT.validador)
     ------------------------------------------------------------------------ */
  FT.validador = {
    ejecutarValidacionCompleta: function () {
      var errores = [];
      var advertencias = [];
      var farmacos = FT.datos.farmacos || {};
      var patologias = FT.datos.patologias || {};
      var temas = FT.datos.temas || {};

      /* 2.1 Validar Fármacos */
      Object.keys(farmacos).forEach(function (fId) {
        var f = farmacos[fId];
        if (!f.dci || !f.familia) {
          errores.push('Fármaco [' + fId + '] carece de DCI o familia.');
        }
        if (!f.temaId || !temas[f.temaId]) {
          errores.push('Fármaco [' + fId + '] apunta a un temaId inexistente: ' + f.temaId);
        }
        if (!f.ref || !f.ref.archivo || !f.ref.tema || !f.ref.pagina) {
          errores.push('Fármaco [' + fId + '] incumple la Regla 2 de Trazabilidad (falta archivo, tema o página).');
        }
        if (!Array.isArray(f.formasVias) || f.formasVias.length === 0) {
          errores.push('Fármaco [' + fId + '] no tiene formas farmacéuticas ni vías definidas.');
        }
        if (!f.mnemotecnia) {
          advertencias.push('Fármaco [' + fId + '] no incluye regla mnemotécnica.');
        }
      });

      /* 2.2 Validar Patologías / Casos y sus referencias cruzadas */
      Object.keys(patologias).forEach(function (pId) {
        var p = patologias[pId];
        if (!p.solucionOptima || !p.solucionOptima.farmacoId) {
          errores.push('Patología [' + pId + '] no tiene solucionOptima definida.');
        } else if (!farmacos[p.solucionOptima.farmacoId]) {
          errores.push(
            'Patología [' + pId + '] referencia un fármaco óptimo que no existe: ' + p.solucionOptima.farmacoId
          );
        }
        if (!p.ref || !p.ref.archivo || !p.ref.pagina) {
          errores.push('Patología [' + pId + '] carece de referencia trazable al temario.');
        }
      });

      var resultado = {
        valido: errores.length === 0,
        totalFarmacos: Object.keys(farmacos).length,
        totalPatologias: Object.keys(patologias).length,
        totalTemas: Object.keys(temas).length,
        errores: errores,
        advertencias: advertencias,
        fechaRevision: new Date().toLocaleTimeString('es-ES')
      };

      FT.bus.emit(FT.EVENTOS.VALIDACION_COMPLETADA, resultado);
      return resultado;
    }
  };

  /* ------------------------------------------------------------------------
     3. CONTROLADOR INTERACTIVO DE LA CONSOLA DE CIMIENTOS (FASE 1.1)
     ------------------------------------------------------------------------ */
  function actualizarHUD() {
    var est = FT.estado.obtener();
    var elNombre = document.getElementById('hud-nombre-hospital');
    var elDinero = document.getElementById('hud-valor-dinero');
    var elRep = document.getElementById('hud-valor-reputacion');
    var elTiempo = document.getElementById('hud-valor-tiempo');
    var elDominio = document.getElementById('hud-valor-dominio');

    if (elNombre) elNombre.textContent = est.hospital.nombre;
    if (elDinero) elDinero.textContent = FT.util.formatearMoneda(est.hospital.dinero);
    if (elRep) {
      var estrellasTxt = '★'.repeat(est.hospital.estrellas) + '☆'.repeat(5 - est.hospital.estrellas);
      elRep.textContent = est.hospital.reputacion + ' pts (' + estrellasTxt + ')';
    }
    if (elTiempo) {
      elTiempo.textContent = 'Día ' + est.hospital.diaActual + ' · ' + FT.util.formatearHoraMinutos(est.hospital.minutoDia);
    }
    if (elDominio) {
      var domGlobal = FT.estado.calcularDominioGlobal();
      var etiquetaMedalla = domGlobal >= 90 ? 'Oro' : domGlobal >= 70 ? 'Plata' : domGlobal >= 40 ? 'Bronce' : 'En estudio';
      elDominio.textContent = domGlobal + '% (' + etiquetaMedalla + ')';
    }
  }

  function actualizarConsolaEventos() {
    var caja = document.getElementById('registro-eventos-recientes');
    if (!caja) return;
    var lista = FT.bus.obtenerHistorialReciente().slice(0, 8);
    caja.innerHTML = lista.map(function (item) {
      return (
        '<div class="consola-linea">' +
          '<strong>[' + FT.util.escaparHtml(item.hora) + ']</strong> ' +
          '<span style="color:#38BDF8">' + FT.util.escaparHtml(item.evento) + '</span> → ' +
          FT.util.escaparHtml(item.resumen) +
        '</div>'
      );
    }).join('');
  }

  function renderizarMuestraFarmacos() {
    var contenedor = document.getElementById('contenedor-muestra-farmacos');
    if (!contenedor) return;

    var html = Object.keys(FT.datos.farmacos).map(function (id) {
      var f = FT.datos.farmacos[id];
      var vias = f.formasVias.map(function (fv) {
        return fv.forma + ' (' + fv.via + ')';
      }).join(', ');

      return (
        '<article class="ficha-farmaco-cromo">' +
          '<div class="ficha-farmaco-titulo">' +
            '<h3>' + FT.util.escaparHtml(f.dci) + '</h3>' +
            (f.codigoATC ? '<span class="badge badge-primario codigo-atc">ATC: ' + FT.util.escaparHtml(f.codigoATC) + '</span>' : '<span class="badge badge-exito">DCI</span>') +
          '</div>' +
          '<p class="texto-secundario"><strong>Nombres en temario:</strong> ' + FT.util.escaparHtml(f.nombresTemario.join(', ')) + '</p>' +
          '<p class="texto-secundario"><strong>Familia:</strong> ' + FT.util.escaparHtml(f.familia) + '</p>' +
          '<p class="texto-secundario"><strong>Formas y vía:</strong> ' + FT.util.escaparHtml(vias) + '</p>' +
          '<p class="texto-secundario"><strong>Cuidado enfermero:</strong> ' + FT.util.escaparHtml(f.cuidadosEnfermeria[0]) + '</p>' +
          '<p class="texto-secundario"><strong>💡 Mnemotecnia (Carmen):</strong> <em>«' + FT.util.escaparHtml(f.mnemotecnia) + '»</em></p>' +
          '<div class="ficha-ref-trazabilidad">' +
            '📌 Origen: ' + FT.util.escaparHtml(f.ref.archivo) + ' · ' + FT.util.escaparHtml(f.ref.seccion) + ' (Pág. ' + FT.util.escaparHtml(f.ref.pagina) + ')' +
          '</div>' +
        '</article>'
      );
    }).join('');

    contenedor.innerHTML = html;
  }

  function dibujarFondoIsometricoDecorativo() {
    var canvas = document.getElementById('lienzo-hospital');
    if (!canvas || !canvas.getContext) return;
    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#1E6091';
    ctx.lineWidth = 1;

    var tileW = 64;
    var tileH = 32;
    var origenX = canvas.width / 2;
    var origenY = 60;

    for (var x = 0; x <= 12; x++) {
      for (var y = 0; y <= 12; y++) {
        var isoX = origenX + (x - y) * (tileW / 2);
        var isoY = origenY + (x + y) * (tileH / 2);
        ctx.beginPath();
        ctx.moveTo(isoX, isoY);
        ctx.lineTo(isoX + tileW / 2, isoY + tileH / 2);
        ctx.lineTo(isoX, isoY + tileH);
        ctx.lineTo(isoX - tileW / 2, isoY + tileH / 2);
        ctx.closePath();
        ctx.stroke();
      }
    }
  }

  function abrirModal(titulo, contenidoHtml) {
    var backdrop = document.getElementById('modal-backdrop');
    var elTitulo = document.getElementById('modal-titulo');
    var elCuerpo = document.getElementById('modal-contenido');
    if (!backdrop || !elTitulo || !elCuerpo) return;

    elTitulo.textContent = titulo;
    elCuerpo.innerHTML = contenidoHtml;
    backdrop.classList.remove('oculto');
  }

  function cerrarModal() {
    var backdrop = document.getElementById('modal-backdrop');
    if (backdrop) backdrop.classList.add('oculto');
  }

  function mostrarModalPartidas() {
    var ranuras = FT.guardado.obtenerResumenRanuras();
    var activa = FT.estado.obtener().meta.ranuraId;

    var filasHtml = ranuras.map(function (r) {
      var esActiva = r.ranuraId === activa;
      var info = r.vacia
        ? '<span class="texto-suave">Ranura vacía — Se creará partida nueva al cargar</span>'
        : '<strong>' + FT.util.escaparHtml(r.nombreHospital) + '</strong> · Día ' + r.dia + ' · ' +
          FT.util.formatearMoneda(r.dinero) + ' <span class="texto-suave">(Guardado: ' + FT.util.escaparHtml(r.fecha) + ')</span>';

      return (
        '<div class="ranura-guardado-item">' +
          '<div>' +
            '<span class="badge ' + (esActiva ? 'badge-primario' : 'badge-exito') + '">Ranura ' + r.ranuraId + (esActiva ? ' (Activa)' : '') + '</span> ' +
            '<div style="margin-top:0.3rem">' + info + '</div>' +
          '</div>' +
          '<div class="grupo-botones-prueba">' +
            '<button type="button" class="btn btn-primario btn-xs" data-accion="guardar-slot" data-slot="' + r.ranuraId + '">Guardar aquí</button>' +
            '<button type="button" class="btn btn-secundario btn-xs" data-accion="cargar-slot" data-slot="' + r.ranuraId + '">Cargar</button>' +
            '<button type="button" class="btn btn-danino btn-xs" data-accion="reiniciar-slot" data-slot="' + r.ranuraId + '">Reiniciar</button>' +
          '</div>' +
        '</div>'
      );
    }).join('');

    var codigoExportado = FT.guardado.exportarComoTexto();
    var html =
      '<p class="texto-secundario">Selecciona una de las 3 ranuras locales o exporta/importa tu partida como texto para conservar tu progreso entre ordenadores o chats:</p>' +
      filasHtml +
      '<hr style="border:none;border-top:1px solid var(--color-borde)">' +
      '<div>' +
        '<strong>Exportar / Importar partida como código de texto:</strong>' +
        '<textarea id="input-codigo-partida" class="textarea-exportacion" style="margin-top:0.4rem">' + FT.util.escaparHtml(codigoExportado) + '</textarea>' +
        '<div class="grupo-botones-prueba" style="margin-top:0.5rem">' +
          '<button type="button" id="btn-modal-copiar-save" class="btn btn-primario btn-sm">📋 Copiar código de partida</button>' +
          '<button type="button" id="btn-modal-importar-save" class="btn btn-exito btn-sm">📥 Importar código pegado arriba</button>' +
        '</div>' +
      '</div>';

    abrirModal('💾 Gestión de Partidas y Exportación', html);

    var cuerpo = document.getElementById('modal-contenido');
    cuerpo.querySelectorAll('[data-accion]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var accion = btn.getAttribute('data-accion');
        var slot = Number(btn.getAttribute('data-slot'));
        if (accion === 'guardar-slot') {
          FT.guardado.guardarRanura(slot);
          FT.util.mostrarToast('Partida guardada en la Ranura ' + slot);
          mostrarModalPartidas();
        } else if (accion === 'cargar-slot') {
          FT.guardado.cargarRanura(slot);
          actualizarHUD();
          FT.util.mostrarToast('Ranura ' + slot + ' cargada.');
          mostrarModalPartidas();
        } else if (accion === 'reiniciar-slot') {
          FT.estado.reiniciarRanuraActiva(slot);
          actualizarHUD();
          FT.util.mostrarToast('Ranura ' + slot + ' reiniciada de fábrica.');
          mostrarModalPartidas();
        }
      });
    });

    var btnCopiarSave = document.getElementById('btn-modal-copiar-save');
    var btnImportarSave = document.getElementById('btn-modal-importar-save');
    var areaTexto = document.getElementById('input-codigo-partida');

    if (btnCopiarSave && areaTexto) {
      btnCopiarSave.addEventListener('click', function () {
        areaTexto.select();
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(areaTexto.value);
        }
        FT.util.mostrarToast('Código de partida copiado al portapapeles.');
      });
    }

    if (btnImportarSave && areaTexto) {
      btnImportarSave.addEventListener('click', function () {
        try {
          FT.guardado.importarDesdeTexto(areaTexto.value);
          actualizarHUD();
          FT.util.mostrarToast('Partida importada y migrada con éxito.');
          mostrarModalPartidas();
        } catch (err) {
          FT.util.mostrarToast('Código inválido: ' + err.message, 'error');
        }
      });
    }
  }

  function mostrarModalValidador() {
    var res = FT.validador.ejecutarValidacionCompleta();
    var estadoHtml = res.valido
      ? '<div class="alerta-evaluacion nivel-optima"><span class="icono-nivel">✓</span><div><strong>VALIDACIÓN SUPERADA (0 ERRORES)</strong><span>Todos los fármacos, patologías y referencias al temario son íntegros y trazables.</span></div></div>'
      : '<div class="alerta-evaluacion nivel-danina"><span class="icono-nivel">✖</span><div><strong>ERRORES DE INTEGRIDAD DETECTADOS (' + res.errores.length + ')</strong><span>Revisa la lista inferior.</span></div></div>';

    var listaErrores = res.errores.length === 0
      ? '<p class="texto-secundario">No se han encontrado referencias rotas ni campos vacíos.</p>'
      : '<ul>' + res.errores.map(function (e) { return '<li>' + FT.util.escaparHtml(e) + '</li>'; }).join('') + '</ul>';

    var html =
      estadoHtml +
      '<div class="ranura-guardado-item">' +
        '<div><strong>Temas registrados:</strong> ' + res.totalTemas + '</div>' +
        '<div><strong>Fármacos validados:</strong> ' + res.totalFarmacos + '</div>' +
        '<div><strong>Plantillas de casos:</strong> ' + res.totalPatologias + '</div>' +
        '<div><strong>Hora:</strong> ' + res.fechaRevision + '</div>' +
      '</div>' +
      '<h3>Detalle de comprobación de trazabilidad:</h3>' +
      listaErrores;

    abrirModal('🔍 Informe del Validador de Base de Conocimiento', html);
  }

  function mostrarModalAccesibilidad() {
    var aj = FT.estado.obtener().ajustes;
    var html =
      '<div class="ranura-guardado-item">' +
        '<div>' +
          '<strong>Paleta apta para daltonismo (Okabe-Ito)</strong>' +
          '<p class="texto-secundario">Sustituye verdes/rojos convencionales por azul-esmeralda, ámbar y carmesí violáceo de alto contraste.</p>' +
        '</div>' +
        '<button type="button" id="btn-toggle-daltonismo" class="btn btn-primario btn-sm">' +
          (aj.paleta === 'daltonismo' ? 'Activada (Cambiar a Estándar)' : 'Desactivada (Activar Daltonismo)') +
        '</button>' +
      '</div>' +
      '<div class="ranura-guardado-item">' +
        '<div>' +
          '<strong>Tamaño del texto de la interfaz</strong>' +
          '<p class="texto-secundario">Ajusta la escala tipográfica global para sesiones largas de estudio.</p>' +
        '</div>' +
        '<div class="grupo-botones-prueba">' +
          '<button type="button" class="btn btn-secundario btn-xs" data-escala="normal">Normal (100%)</button>' +
          '<button type="button" class="btn btn-secundario btn-xs" data-escala="grande">Grande (115%)</button>' +
          '<button type="button" class="btn btn-secundario btn-xs" data-escala="muy-grande">Muy Grande (125%)</button>' +
        '</div>' +
      '</div>' +
      '<div class="ranura-guardado-item">' +
        '<div>' +
          '<strong>Reducir animaciones y movimiento</strong>' +
          '<p class="texto-secundario">Suprime rebotes y transiciones rápidas.</p>' +
        '</div>' +
        '<button type="button" id="btn-toggle-movimiento" class="btn btn-secundario btn-sm">' +
          (aj.reducirMovimiento ? 'Activado (Restaurar animaciones)' : 'Desactivado (Reducir movimiento)') +
        '</button>' +
      '</div>';

    abrirModal('♿ Accesibilidad y Preferencias Visuales', html);

    var btnDalt = document.getElementById('btn-toggle-daltonismo');
    if (btnDalt) {
      btnDalt.addEventListener('click', function () {
        var nueva = FT.estado.obtener().ajustes.paleta === 'daltonismo' ? 'estandar' : 'daltonismo';
        FT.estado.actualizarAjustes({ paleta: nueva });
        FT.util.mostrarToast('Paleta cambiada a: ' + nueva);
        mostrarModalAccesibilidad();
      });
    }

    document.querySelectorAll('[data-escala]').forEach(function (b) {
      b.addEventListener('click', function () {
        var esc = b.getAttribute('data-escala');
        FT.estado.actualizarAjustes({ escalaTexto: esc });
        FT.util.mostrarToast('Escala de texto ajustada a: ' + esc);
      });
    });

    var btnMov = document.getElementById('btn-toggle-movimiento');
    if (btnMov) {
      btnMov.addEventListener('click', function () {
        var nuevoMov = !FT.estado.obtener().ajustes.reducirMovimiento;
        FT.estado.actualizarAjustes({ reducirMovimiento: nuevoMov });
        FT.util.mostrarToast('Reducción de movimiento: ' + (nuevoMov ? 'Sí' : 'No'));
        mostrarModalAccesibilidad();
      });
    }
  }

  function mostrarModalAcercaDe() {
    var html =
      '<div class="alerta-evaluacion nivel-aceptable">' +
        '<span class="icono-nivel">▲</span>' +
        '<div>' +
          '<strong>AVISO ACADÉMICO Y LEGAL (REGLA INNEGOCIABLE Nº 7)</strong>' +
          '<span>Esta aplicación es exclusivamente una herramienta interactiva de estudio y repaso universitario para la asignatura de Farmacología en Enfermería. En ningún caso constituye consejo médico, diagnóstico ni pauta de prescripción asistencial real.</span>' +
        '</div>' +
      '</div>' +
      '<p class="texto-secundario"><strong>Título:</strong> Vademécum Tycoon: Dirección Clínica</p>' +
      '<p class="texto-secundario"><strong>Fuente única de verdad farmacológica:</strong> Temario oficial adjunto por el estudiante (Grado en Enfermería · Universidad Europea).</p>' +
      '<p class="texto-secundario"><strong>Arquitectura técnica:</strong> HTML5 + CSS3 + JavaScript puro (ES5/ES6 sin módulos ni dependencias externas, 100% compatible con ejecución local <code>file://</code>).</p>';

    abrirModal('ℹ️ Acerca de Vademécum Tycoon', html);
  }

  /* Inicialización al cargar el DOM */
  document.addEventListener('DOMContentLoaded', function () {
    var slotActivo = Number(localStorage.getItem('vademecum_tycoon_activa')) || 1;
    FT.guardado.cargarRanura(slotActivo);

    FT.bus.on(FT.EVENTOS.ESTADO_CAMBIADO, function () {
      actualizarHUD();
      actualizarConsolaEventos();
    });

    var resVal = FT.validador.ejecutarValidacionCompleta();
    var badgeVal = document.getElementById('badge-estado-validador');
    if (badgeVal) {
      badgeVal.textContent = resVal.valido ? 'OK · ' + resVal.totalFarmacos + ' fármacos' : 'ERROR';
    }

    actualizarHUD();
    actualizarConsolaEventos();
    renderizarMuestraFarmacos();
    dibujarFondoIsometricoDecorativo();

    /* Enlaces de botones de prueba de la Fase 1.1 */
    document.getElementById('btn-test-ingresar').addEventListener('click', function () {
      FT.estado.modificarDinero(500, 'Caso clínico resuelto en nivel ÓPTIMO');
      FT.estado.modificarReputacion(20, 'Paciente dado de alta sin RAM');
      FT.util.mostrarToast('+500 € y +20 Reputación (Decisión Óptima)');
    });

    document.getElementById('btn-test-multa').addEventListener('click', function () {
      FT.estado.modificarDinero(-300, 'Gasto de rescate por RAM');
      FT.estado.modificarReputacion(-20, 'Reclamación en planta');
      FT.util.mostrarToast('-300 € y -20 Reputación (Alerta de Farmacovigilancia)', 'error');
    });

    document.getElementById('btn-test-avanzar-hora').addEventListener('click', function () {
      FT.estado.avanzarTiempoMinutos(60);
    });

    document.getElementById('btn-test-subir-dominio').addEventListener('click', function () {
      FT.estado.registrarProgresoTema('t1', 15);
      FT.util.mostrarToast('Dominio del Tema 1 incrementado (+15%).');
    });

    document.getElementById('btn-test-error').addEventListener('click', function () {
      FT.errores.simularErrorPrueba();
    });

    document.getElementById('btn-test-migracion').addEventListener('click', function () {
      var infoMig = FT.guardado.ejecutarPruebaMigracionV1aV2();
      var cajaMig = document.getElementById('resultado-test-migracion');
      if (cajaMig) {
        cajaMig.innerHTML =
          '<strong>Resultado:</strong> ' + (infoMig.exito ? '✅ ÉXITO' : '❌ FALLO') +
          ' | Ruta: <code>' + infoMig.pasos.join(', ') + '</code>' +
          ' | Subvención SNS añadida: <code>' + infoMig.subvencionAnadida + ' €</code>' +
          ' | Versión final: <code>v' + infoMig.versionFinal + '</code>';
      }
      FT.util.mostrarToast('Prueba de migración v1 → v2 superada.');
    });

    document.getElementById('btn-test-autoguardado').addEventListener('click', function () {
      FT.guardado.guardarRanura();
      actualizarConsolaEventos();
      FT.util.mostrarToast('Partida guardada en localStorage.');
    });

    /* Botones de la barra superior */
    document.getElementById('btn-abrir-guardado').addEventListener('click', mostrarModalPartidas);
    document.getElementById('btn-abrir-validador').addEventListener('click', mostrarModalValidador);
    document.getElementById('btn-abrir-accesibilidad').addEventListener('click', mostrarModalAccesibilidad);
    document.getElementById('btn-abrir-acerca').addEventListener('click', mostrarModalAcercaDe);
    document.getElementById('btn-cerrar-modal').addEventListener('click', cerrarModal);
    document.getElementById('modal-backdrop').addEventListener('click', function (ev) {
      if (ev.target.id === 'modal-backdrop') cerrarModal();
    });
  });

})(window.FT = window.FT || {});