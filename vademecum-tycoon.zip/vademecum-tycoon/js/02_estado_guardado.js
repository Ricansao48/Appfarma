/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/02_estado_guardado.js
   Responsabilidad: Estado central serializable, gestión de 3 ranuras en
   localStorage, sistema de migración entre versiones y exportación/importación
   en texto (Base64 UTF-8 seguro) para continuidad entre chats.
   ========================================================================== */

(function (FT) {
  'use strict';

  var VERSION_ESQUEMA_GUARDADO = 2;
  var PREFIJO_RANURA = 'vademecum_tycoon_slot_';
  var CLAVE_RANURA_ACTIVA = 'vademecum_tycoon_activa';

  /* ------------------------------------------------------------------------
     1. GENERADOR DEL ESTADO INICIAL SERIALIZABLE
     ------------------------------------------------------------------------ */
  function crearEstadoPorDefecto(ranuraId) {
    return {
      meta: {
        versionEsquema: VERSION_ESQUEMA_GUARDADO,
        versionCodigo: FT.VERSION_CODIGO,
        fechaCreacion: new Date().toISOString(),
        fechaUltimoGuardado: new Date().toISOString(),
        ranuraId: ranuraId || 1,
        modoJuego: 'campana' // 'estudio' | 'campana' | 'libre' | 'reto' | 'examen'
      },
      hospital: {
        nombre: 'Hospital Clínico Universitario',
        colorPrimario: '#1E6091',
        dinero: 12500,
        subvencionBasalSNS: 1500,
        reputacion: 100, // 0 a 500 (cada 100 = 1 estrella)
        estrellas: 2,
        diaActual: 1,
        minutoDia: 480, // 08:00 AM
        velocidadJuego: 1, // 0: pausa, 1: x1, 2: x2, 3: x3
        departamentosDesbloqueados: ['D1'],
        salasConstruidas: [
          { id: 'sala_triaje_1', tipo: 'consulta_general', departamentoId: 'D1', x: 2, y: 2, nivel: 1 }
        ],
        personalContratado: [
          {
            id: 'pers_carmen',
            nombre: 'Supervisora Carmen',
            rol: 'enfermera_jefa',
            especialidadUnidad: 'u1',
            nivel: 3,
            sueldoDiario: 250,
            moral: 95
          }
        ],
        investigacionDesbloqueada: ['inv_vademecum_basico']
      },
      aprendizaje: {
        dominioPorTema: {
          t1: { aciertos: 0, intentos: 0, porcentaje: 0, medalla: 'sin_medalla', ultimoRepasoDia: 0 },
          t2: { aciertos: 0, intentos: 0, porcentaje: 0, medalla: 'sin_medalla', ultimoRepasoDia: 0 },
          t3: { aciertos: 0, intentos: 0, porcentaje: 0, medalla: 'sin_medalla', ultimoRepasoDia: 0 },
          t4: { aciertos: 0, intentos: 0, porcentaje: 0, medalla: 'sin_medalla', ultimoRepasoDia: 0 }
        },
        dominioPorFarmaco: {},
        cromosDesbloqueados: ['f_paracetamol', 'f_acido_acetilsalicilico', 'f_metamizol'],
        rachaActual: 0,
        mejorRacha: 0,
        erroresFrecuentes: []
      },
      ajustes: {
        paleta: 'estandar', // 'estandar' | 'daltonismo'
        escalaTexto: 'normal', // 'normal' | 'grande' | 'muy-grande'
        reducirMovimiento: false,
        silenciado: false,
        volumenEfectos: 0.7,
        volumenMusica: 0.4,
        mostrarPistas: true
      }
    };
  }

  /* ------------------------------------------------------------------------
     2. TUBERÍA DE MIGRACIONES DE VERSIÓN (v1 -> v2 -> futuras)
     ------------------------------------------------------------------------ */
  var migraciones = {
    /* Migra partidas de esquema v1 al esquema v2 sin perder progreso */
    1: function (estadoV1) {
      var migrado = FT.util.clonarProfundo(estadoV1);
      migrado.meta = migrado.meta || {};
      migrado.meta.versionEsquema = 2;

      if (!migrado.hospital) migrado.hospital = {};
      if (typeof migrado.hospital.subvencionBasalSNS !== 'number') {
        migrado.hospital.subvencionBasalSNS = 1500;
      }
      if (!Array.isArray(migrado.hospital.investigacionDesbloqueada)) {
        migrado.hospital.investigacionDesbloqueada = ['inv_vademecum_basico'];
      }

      if (!migrado.aprendizaje) migrado.aprendizaje = {};
      if (!Array.isArray(migrado.aprendizaje.erroresFrecuentes)) {
        migrado.aprendizaje.erroresFrecuentes = [];
      }

      return migrado;
    }
  };

  function migrarHastaVersionActual(datosCargados) {
    if (!datosCargados || typeof datosCargados !== 'object') {
      throw new Error('El objeto de partida está vacío o dañado.');
    }

    var copia = FT.util.clonarProfundo(datosCargados);
    var versionOrigen = (copia.meta && copia.meta.versionEsquema) ? Number(copia.meta.versionEsquema) : 1;
    var pasosAplicados = [];

    while (versionOrigen < VERSION_ESQUEMA_GUARDADO) {
      var fnMigracion = migraciones[versionOrigen];
      if (typeof fnMigracion !== 'function') {
        throw new Error('No existe ruta de migración desde la versión ' + versionOrigen);
      }
      copia = fnMigracion(copia);
      pasosAplicados.push('v' + versionOrigen + ' → v' + copia.meta.versionEsquema);
      versionOrigen = copia.meta.versionEsquema;
    }

    /* Rellenar con valores por defecto cualquier clave nueva que falte */
    var plantilla = crearEstadoPorDefecto(copia.meta ? copia.meta.ranuraId : 1);
    copia.hospital = Object.assign({}, plantilla.hospital, copia.hospital || {});
    copia.aprendizaje = Object.assign({}, plantilla.aprendizaje, copia.aprendizaje || {});
    copia.ajustes = Object.assign({}, plantilla.ajustes, copia.ajustes || {});
    copia.meta.versionCodigo = FT.VERSION_CODIGO;

    return {
      estadoMigrado: copia,
      pasosAplicados: pasosAplicados
    };
  }

  /* ------------------------------------------------------------------------
     3. API PÚBLICA DE ESTADO ACTIVO (FT.estado)
     ------------------------------------------------------------------------ */
  var estadoActivo = crearEstadoPorDefecto(1);

  function calcularMedalla(porcentaje) {
    if (porcentaje >= 90) return 'oro';
    if (porcentaje >= 70) return 'plata';
    if (porcentaje >= 40) return 'bronce';
    return 'sin_medalla';
  }

  FT.estado = {
    obtener: function () {
      return estadoActivo;
    },

    reiniciarRanuraActiva: function (ranuraId) {
      estadoActivo = crearEstadoPorDefecto(ranuraId || estadoActivo.meta.ranuraId);
      this.aplicarAjustesVisualesAlDOM();
      FT.bus.emit(FT.EVENTOS.ESTADO_INICIALIZADO, estadoActivo);
      FT.guardado.guardarRanura(estadoActivo.meta.ranuraId);
      return estadoActivo;
    },

    modificarDinero: function (delta, motivo) {
      estadoActivo.hospital.dinero = Math.max(0, estadoActivo.hospital.dinero + Number(delta));
      FT.bus.emit(FT.EVENTOS.ECONOMIA_ACTUALIZADA, {
        dinero: estadoActivo.hospital.dinero,
        delta: delta,
        motivo: motivo || 'Operación clínica'
      });
      FT.bus.emit(FT.EVENTOS.ESTADO_CAMBIADO, estadoActivo);
    },

    modificarReputacion: function (delta, motivo) {
      var rep = FT.util.clamp(estadoActivo.hospital.reputacion + Number(delta), 0, 500);
      estadoActivo.hospital.reputacion = rep;
      estadoActivo.hospital.estrellas = FT.util.clamp(Math.ceil(rep / 100), 1, 5);
      FT.bus.emit(FT.EVENTOS.REPUTACION_ACTUALIZADA, {
        reputacion: rep,
        estrellas: estadoActivo.hospital.estrellas,
        delta: delta,
        motivo: motivo || 'Evaluación de paciente'
      });
      FT.bus.emit(FT.EVENTOS.ESTADO_CAMBIADO, estadoActivo);
    },

    avanzarTiempoMinutos: function (minutos) {
      estadoActivo.hospital.minutoDia += Number(minutos);
      while (estadoActivo.hospital.minutoDia >= 1440) {
        estadoActivo.hospital.minutoDia -= 1440;
        estadoActivo.hospital.diaActual += 1;
      }
      FT.bus.emit(FT.EVENTOS.TIEMPO_AVANZADO, {
        diaActual: estadoActivo.hospital.diaActual,
        minutoDia: estadoActivo.hospital.minutoDia
      });
      FT.bus.emit(FT.EVENTOS.ESTADO_CAMBIADO, estadoActivo);
    },

    registrarProgresoTema: function (temaId, deltaPorcentaje) {
      var mapa = estadoActivo.aprendizaje.dominioPorTema;
      if (!mapa[temaId]) {
        mapa[temaId] = { aciertos: 0, intentos: 0, porcentaje: 0, medalla: 'sin_medalla', ultimoRepasoDia: 1 };
      }
      var reg = mapa[temaId];
      reg.intentos += 1;
      if (deltaPorcentaje > 0) reg.aciertos += 1;
      reg.porcentaje = FT.util.clamp(reg.porcentaje + Number(deltaPorcentaje), 0, 100);
      reg.medalla = calcularMedalla(reg.porcentaje);
      reg.ultimoRepasoDia = estadoActivo.hospital.diaActual;

      FT.bus.emit(FT.EVENTOS.DOMINIO_ACTUALIZADO, {
        temaId: temaId,
        porcentaje: reg.porcentaje,
        medalla: reg.medalla,
        dominioGlobal: this.calcularDominioGlobal()
      });
      FT.bus.emit(FT.EVENTOS.ESTADO_CAMBIADO, estadoActivo);
    },

    calcularDominioGlobal: function () {
      var mapa = estadoActivo.aprendizaje.dominioPorTema;
      var claves = Object.keys(mapa);
      if (claves.length === 0) return 0;
      var suma = claves.reduce(function (acc, k) {
        return acc + (mapa[k].porcentaje || 0);
      }, 0);
      return Math.round(suma / claves.length);
    },

    actualizarAjustes: function (nuevosAjustes) {
      Object.assign(estadoActivo.ajustes, nuevosAjustes || {});
      this.aplicarAjustesVisualesAlDOM();
      FT.bus.emit(FT.EVENTOS.AJUSTES_CAMBIADOS, estadoActivo.ajustes);
      FT.guardado.guardarRanura(estadoActivo.meta.ranuraId);
    },

    aplicarAjustesVisualesAlDOM: function () {
      var raiz = document.documentElement;
      raiz.setAttribute('data-paleta', estadoActivo.ajustes.paleta || 'estandar');
      raiz.setAttribute('data-escala-texto', estadoActivo.ajustes.escalaTexto || 'normal');
      raiz.setAttribute('data-reducir-movimiento', String(Boolean(estadoActivo.ajustes.reducirMovimiento)));
    }
  };

  /* ------------------------------------------------------------------------
     4. GESTOR DE GUARDADO EN LOCALSTORAGE Y EXPORTACIÓN BASE64 (FT.guardado)
     ------------------------------------------------------------------------ */
  function codificarBase64UTF8(texto) {
    return btoa(encodeURIComponent(texto).replace(/%([0-9A-F]{2})/g, function (_, p1) {
      return String.fromCharCode('0x' + p1);
    }));
  }

  function decodificarBase64UTF8(base64) {
    return decodeURIComponent(Array.prototype.map.call(atob(base64.trim()), function (c) {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  }

  FT.guardado = {
    guardarRanura: function (ranuraId) {
      var slot = Number(ranuraId) || estadoActivo.meta.ranuraId || 1;
      estadoActivo.meta.ranuraId = slot;
      estadoActivo.meta.fechaUltimoGuardado = new Date().toISOString();
      try {
        localStorage.setItem(PREFIJO_RANURA + slot, JSON.stringify(estadoActivo));
        localStorage.setItem(CLAVE_RANURA_ACTIVA, String(slot));
        FT.bus.emit(FT.EVENTOS.PARTIDA_GUARDADA, { ranuraId: slot, fecha: estadoActivo.meta.fechaUltimoGuardado });
        return true;
      } catch (err) {
        FT.errores.registrarManual('Error al guardar en localStorage: ' + err.message, 'js/02_estado_guardado.js');
        return false;
      }
    },

    cargarRanura: function (ranuraId) {
      var slot = Number(ranuraId) || 1;
      try {
        var crudo = localStorage.getItem(PREFIJO_RANURA + slot);
        if (!crudo) {
          estadoActivo = crearEstadoPorDefecto(slot);
          this.guardarRanura(slot);
        } else {
          var parseado = JSON.parse(crudo);
          var resultado = migrarHastaVersionActual(parseado);
          estadoActivo = resultado.estadoMigrado;
          estadoActivo.meta.ranuraId = slot;
        }
        FT.estado.aplicarAjustesVisualesAlDOM();
        FT.bus.emit(FT.EVENTOS.PARTIDA_CARGADA, { ranuraId: slot, estado: estadoActivo });
        return estadoActivo;
      } catch (err) {
        FT.errores.registrarManual('Error al cargar ranura ' + slot + ': ' + err.message, 'js/02_estado_guardado.js');
        return estadoActivo;
      }
    },

    obtenerResumenRanuras: function () {
      var lista = [];
      for (var i = 1; i <= 3; i++) {
        var crudo = localStorage.getItem(PREFIJO_RANURA + i);
        if (!crudo) {
          lista.push({ ranuraId: i, vacia: true });
        } else {
          try {
            var d = JSON.parse(crudo);
            lista.push({
              ranuraId: i,
              vacia: false,
              nombreHospital: (d.hospital && d.hospital.nombre) || 'Hospital',
              dinero: (d.hospital && d.hospital.dinero) || 0,
              dia: (d.hospital && d.hospital.diaActual) || 1,
              fecha: (d.meta && d.meta.fechaUltimoGuardado) ? new Date(d.meta.fechaUltimoGuardado).toLocaleString('es-ES') : '—'
            });
          } catch (_) {
            lista.push({ ranuraId: i, vacia: true, corrupta: true });
          }
        }
      }
      return lista;
    },

    exportarComoTexto: function () {
      return 'VT_SAVE_V2::' + codificarBase64UTF8(JSON.stringify(estadoActivo));
    },

    importarDesdeTexto: function (cadenaExportada) {
      if (!cadenaExportada || typeof cadenaExportada !== 'string') {
        throw new Error('Cadena de importación vacía.');
      }
      var limpia = cadenaExportada.trim().replace(/^VT_SAVE_V\d+::/, '');
      var jsonTexto = decodificarBase64UTF8(limpia);
      var objeto = JSON.parse(jsonTexto);
      var migrado = migrarHastaVersionActual(objeto);
      estadoActivo = migrado.estadoMigrado;
      this.guardarRanura(estadoActivo.meta.ranuraId);
      FT.estado.aplicarAjustesVisualesAlDOM();
      FT.bus.emit(FT.EVENTOS.PARTIDA_CARGADA, { ranuraId: estadoActivo.meta.ranuraId, estado: estadoActivo });
      return estadoActivo;
    },

    ejecutarPruebaMigracionV1aV2: function () {
      var partidaAntiguaSimuladaV1 = {
        meta: { versionEsquema: 1, ranuraId: 1 },
        hospital: { nombre: 'Hospital Antiguo v1', dinero: 8900, reputacion: 150, diaActual: 4 }
      };
      var resultado = migrarHastaVersionActual(partidaAntiguaSimuladaV1);
      return {
        exito: resultado.estadoMigrado.meta.versionEsquema === VERSION_ESQUEMA_GUARDADO,
        pasos: resultado.pasosAplicados,
        subvencionAnadida: resultado.estadoMigrado.hospital.subvencionBasalSNS,
        versionFinal: resultado.estadoMigrado.meta.versionEsquema
      };
    }
  };

})(window.FT = window.FT || {});