/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/03_audio_procedural.js
   Responsabilidad: Sintetizador Web Audio API 100% procedural (sin archivos
   externos). Efectos de UI, caja registradora, alerta de RAM, monitor ECG y
   ambiente hospitalario relajante.
   ========================================================================== */

(function (FT) {
  'use strict';

  var ctxAudio = null;
  var silenciado = false;

  function asegurarContexto() {
    if (silenciado) return null;
    if (!ctxAudio) {
      var AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        ctxAudio = new AudioCtx();
      }
    }
    if (ctxAudio && ctxAudio.state === 'suspended') {
      ctxAudio.resume();
    }
    return ctxAudio;
  }

  function tocarNota(frecuencia, duracionSeg, tipoOnda, gananciaMax, retardoSeg) {
    var ctx = asegurarContexto();
    if (!ctx) return;

    var inicio = ctx.currentTime + (retardoSeg || 0);
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();

    osc.type = tipoOnda || 'sine';
    osc.frequency.setValueAtTime(frecuencia, inicio);

    var vol = (gananciaMax || 0.12);
    gain.gain.setValueAtTime(0.0001, inicio);
    gain.gain.linearRampToValueAtTime(vol, inicio + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, inicio + duracionSeg);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(inicio);
    osc.stop(inicio + duracionSeg + 0.02);
  }

  FT.audio = {
    tocarClick: function () {
      tocarNota(660, 0.05, 'triangle', 0.08, 0);
    },

    tocarSeleccion: function () {
      tocarNota(523.25, 0.07, 'sine', 0.1, 0);
      tocarNota(659.25, 0.09, 'sine', 0.1, 0.05);
    },

    tocarExitoMonedas: function () {
      tocarNota(587.33, 0.1, 'triangle', 0.14, 0);
      tocarNota(880.0, 0.12, 'triangle', 0.14, 0.08);
      tocarNota(1174.66, 0.22, 'sine', 0.16, 0.16);
    },

    tocarAlertaRAM: function () {
      tocarNota(311.13, 0.16, 'sawtooth', 0.12, 0);
      tocarNota(233.08, 0.26, 'sawtooth', 0.14, 0.15);
    },

    tocarLatidoECG: function () {
      tocarNota(987.77, 0.06, 'sine', 0.06, 0);
    },

    alternarSilencio: function () {
      silenciado = !silenciado;
      if (FT.estado) {
        FT.estado.actualizarAjustes({ silenciado: silenciado });
      }
      if (!silenciado) {
        this.tocarSeleccion();
      }
      return silenciado;
    },

    estaSilenciado: function () {
      return silenciado;
    }
  };

})(window.FT = window.FT || {});