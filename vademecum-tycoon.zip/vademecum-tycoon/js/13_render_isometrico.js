/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/13_render_isometrico.js
   Responsabilidad: Motor Gráfico 2.5D / 3D Isométrico en Canvas 2D con
   circulación real del Enfermero Marcos (Farmacia -> Cama del paciente),
   iconos de medicación en mano, partículas clínicas y cámara táctil iPad.
   ========================================================================== */

(function (FT) {
  'use strict';

  var TILE_W = 76;
  var TILE_H = 38;
  var MAPA_FILAS = 12;
  var MAPA_COLS = 12;

  var canvas = null;
  var ctx = null;

  var camara = {
    x: 0,
    y: 85,
    zoom: 1.0,
    arrastrando: false,
    inicioX: 0,
    inicioY: 0,
    modoNocturno: false
  };

  var salasHospital = [
    {
      id: 'sala_recepcion',
      nombre: 'Admisión y Triaje',
      subtitulo: 'Valoración Inicial y HTA',
      x1: 1, y1: 1, x2: 5, y2: 5,
      colorSuelo1: '#F1F5F9',
      colorSuelo2: '#E2E8F0',
      colorPared: '#DCE6F2'
    },
    {
      id: 'sala_consulta_u1',
      nombre: 'Consulta Clínica · Unidad 1',
      subtitulo: 'LADME y Farmacovigilancia (T3-T4)',
      x1: 6, y1: 1, x2: 10, y2: 5,
      colorSuelo1: '#E0F2FE',
      colorSuelo2: '#BAE6FD',
      colorPared: '#CFE8FC'
    },
    {
      id: 'sala_farmacia',
      nombre: 'Farmacia Hospitalaria',
      subtitulo: 'Dispensación EFG y ATC (Tema 1)',
      x1: 1, y1: 6, x2: 5, y2: 10,
      colorSuelo1: '#CCFBF1',
      colorSuelo2: '#99F6E4',
      colorPared: '#C4F1E8'
    },
    {
      id: 'sala_urgencias',
      nombre: 'Box de Observación y Parenteral',
      subtitulo: 'Control de Fiebre, Emesis y Antídotos',
      x1: 6, y1: 6, x2: 10, y2: 10,
      colorSuelo1: '#FEF3C7',
      colorSuelo2: '#FDE68A',
      colorPared: '#F7E5B7'
    }
  ];

  var actores = [
    {
      id: 'act_carmen',
      nombre: 'Supervisora Carmen',
      rol: 'Enfermera Jefa · Mentora',
      avatar: '👩‍⚕️',
      dialogo: '«Toca sobre cualquier paciente para abrir su caso clínico real de la Unidad 1, o usa el botón verde de Consulta Clínica.»',
      x: 3.2, y: 2.6,
      destinoX: 3.2, destinoY: 2.6,
      velocidad: 1.5,
      colorRopa: '#1E6091',
      colorPelo: '#CBD5E1',
      colorPiel: '#F3D1B8',
      etiqueta: '👩‍⚕️ Supervisora Carmen',
      fasePaso: 0,
      esPaciente: false,
      colaDestinos: []
    },
    {
      id: 'act_farmaceutico',
      nombre: 'Dr. Samuel · Farmacia',
      rol: 'Farmacéutico Hospitalario',
      avatar: '👨‍🔬',
      dialogo: '«En esta vitrina custodiamos el Paracetamol STADAGEN 1 g EFG y verificamos el código ATC N02BA01 de la Aspirina®.»',
      x: 3.4, y: 7.8,
      destinoX: 4.1, destinoY: 7.5,
      velocidad: 1.3,
      colorRopa: '#0D9488',
      colorPelo: '#475569',
      colorPiel: '#E8B89A',
      etiqueta: '💊 Farmacia EFG (Caso 2)',
      fasePaso: 1.2,
      esPaciente: true,
      casoId: 'caso_t1_codigo_atc_efg',
      colaDestinos: []
    },
    {
      id: 'act_enfermero_planta',
      nombre: 'Enfermero Marcos',
      rol: 'Enfermero de Planta (5 Correctos)',
      avatar: '🧑‍⚕️',
      dialogo: '«Cuando prescribas un tratamiento iré corriendo a la Farmacia Hospitalaria a recoger la dosis y se la administraré al paciente en su cama.»',
      x: 6.2, y: 5.5,
      destinoX: 6.2, destinoY: 5.5,
      velocidad: 3.2,
      colorRopa: '#2563EB',
      colorPelo: '#1E293B',
      colorPiel: '#F1C27D',
      etiqueta: '💉 Enfermero Marcos',
      fasePaso: 2.4,
      esPaciente: false,
      colaDestinos: []
    },
    {
      id: 'act_paciente_neumonia',
      nombre: 'Paciente: Carlos M. (Caso 1 · T2)',
      rol: 'Neumonía + Fiebre 39,2 °C + Vómitos',
      avatar: '🤒',
      dialogo: '«Tengo 39,2 °C de fiebre y no paro de vomitar... Tócame para elegir la vía de administración correcta.»',
      x: 8.2, y: 7.2,
      destinoX: 8.2, destinoY: 7.2,
      velocidad: 0.9,
      colorRopa: '#E11D48',
      colorPelo: '#78350F',
      colorPiel: '#F3D1B8',
      etiqueta: '🚨 39,2 °C + Vómitos (Caso 1)',
      fasePaso: 0,
      esPaciente: true,
      casoId: 'caso_t2_neumonia_vomitos',
      curado: false,
      colaDestinos: []
    },
    {
      id: 'act_paciente_consulta',
      nombre: 'Paciente: Roberto V. (Caso 3 · T3)',
      rol: 'Dolor Torácico · Primer Paso LADME',
      avatar: '🧔',
      dialogo: '«Tengo opresión en el pecho y Nitroglicerina recetada. ¿Me la pongo debajo de la lengua o me la trago con agua?»',
      x: 8.5, y: 2.8,
      destinoX: 8.5, destinoY: 2.8,
      velocidad: 1.0,
      colorRopa: '#0284C7',
      colorPelo: '#334155',
      colorPiel: '#F1C27D',
      etiqueta: '👅 LADME Sublingual (Caso 3)',
      fasePaso: 0.5,
      esPaciente: true,
      casoId: 'caso_t3_primer_paso_sublingual',
      colaDestinos: []
    },
    {
      id: 'act_paciente_espera',
      nombre: 'Paciente: Dolores S. (Caso 6 · T3)',
      rol: 'Hipoalbuminemia + Fracción Libre',
      avatar: '👵',
      dialogo: '«Tengo la albúmina en 2,4 g/dL. Vigila qué fracción del fármaco queda libre en mi sangre.»',
      x: 3.0, y: 4.1,
      destinoX: 3.0, destinoY: 4.1,
      velocidad: 1.0,
      colorRopa: '#7C3AED',
      colorPelo: '#E2E8F0',
      colorPiel: '#F3D1B8',
      etiqueta: '🔬 Albúmina / Excreción (Caso 6)',
      fasePaso: 0.7,
      esPaciente: true,
      casoId: 'caso_t3_union_proteinas_excrecion',
      colaDestinos: []
    }
  ];

  var particulas = [];
  var actorSeleccionadoId = 'act_paciente_neumonia';
  var tiempoAcumulado = 0;

  function mundoAPantalla(wx, wy, wz) {
    var origenX = (canvas.width / 2) + camara.x;
    var origenY = camara.y;
    var tw = TILE_W * camara.zoom;
    var th = TILE_H * camara.zoom;
    var px = origenX + (wx - wy) * (tw / 2);
    var py = origenY + (wx + wy) * (th / 2) - ((wz || 0) * camara.zoom);
    return { x: px, y: py };
  }

  function pantallaAMundo(px, py) {
    var origenX = (canvas.width / 2) + camara.x;
    var origenY = camara.y;
    var tw = TILE_W * camara.zoom;
    var th = TILE_H * camara.zoom;
    var dx = px - origenX;
    var dy = py - origenY;
    var wx = (dx / (tw / 2) + dy / (th / 2)) / 2;
    var wy = (dy / (th / 2) - dx / (tw / 2)) / 2;
    return { x: wx, y: wy };
  }

  function trazarRectRedondeado(contexto, x, y, ancho, alto, radio) {
    var r = Math.min(radio, ancho / 2, alto / 2);
    contexto.beginPath();
    contexto.moveTo(x + r, y);
    contexto.arcTo(x + ancho, y, x + ancho, y + alto, r);
    contexto.arcTo(x + ancho, y + alto, x, y + alto, r);
    contexto.arcTo(x, y + alto, x, y, r);
    contexto.arcTo(x, y, x + ancho, y, r);
    contexto.closePath();
  }

  function dibujarLosaIsometrica(gx, gy, colorRelleno, colorBorde) {
    var pN = mundoAPantalla(gx, gy, 0);
    var pE = mundoAPantalla(gx + 1, gy, 0);
    var pS = mundoAPantalla(gx + 1, gy + 1, 0);
    var pO = mundoAPantalla(gx, gy + 1, 0);

    ctx.beginPath();
    ctx.moveTo(pN.x, pN.y);
    ctx.lineTo(pE.x, pE.y);
    ctx.lineTo(pS.x, pS.y);
    ctx.lineTo(pO.x, pO.y);
    ctx.closePath();

    ctx.fillStyle = colorRelleno;
    ctx.fill();
    if (colorBorde) {
      ctx.strokeStyle = colorBorde;
      ctx.lineWidth = Math.max(0.6, 1 * camara.zoom);
      ctx.stroke();
    }
  }

  function dibujarBloque3D(wx, wy, wzBase, anchoX, largoY, altoZ, colorArriba, colorIzq, colorDer) {
    var b0 = mundoAPantalla(wx, wy, wzBase);
    var bX = mundoAPantalla(wx + anchoX, wy, wzBase);
    var bXY = mundoAPantalla(wx + anchoX, wy + largoY, wzBase);
    var bY = mundoAPantalla(wx, wy + largoY, wzBase);

    var t0 = mundoAPantalla(wx, wy, wzBase + altoZ);
    var tX = mundoAPantalla(wx + anchoX, wy, wzBase + altoZ);
    var tXY = mundoAPantalla(wx + anchoX, wy + largoY, wzBase + altoZ);
    var tY = mundoAPantalla(wx, wy + largoY, wzBase + altoZ);

    ctx.beginPath();
    ctx.moveTo(t0.x, t0.y);
    ctx.lineTo(tY.x, tY.y);
    ctx.lineTo(bY.x, bY.y);
    ctx.lineTo(b0.x, b0.y);
    ctx.closePath();
    ctx.fillStyle = colorIzq;
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(tY.x, tY.y);
    ctx.lineTo(tXY.x, tXY.y);
    ctx.lineTo(bXY.x, bXY.y);
    ctx.lineTo(bY.x, bY.y);
    ctx.closePath();
    ctx.fillStyle = colorDer;
    ctx.fill();

    ctx.beginPath();
    ctx.moveTo(t0.x, t0.y);
    ctx.lineTo(tX.x, tX.y);
    ctx.lineTo(tXY.x, tXY.y);
    ctx.lineTo(tY.x, tY.y);
    ctx.closePath();
    ctx.fillStyle = colorArriba;
    ctx.fill();

    ctx.strokeStyle = 'rgba(15, 23, 42, 0.22)';
    ctx.lineWidth = Math.max(0.8, 1 * camara.zoom);
    ctx.stroke();
  }

  function obtenerSalaEnCelda(gx, gy) {
    for (var i = 0; i < salasHospital.length; i++) {
      var s = salasHospital[i];
      if (gx >= s.x1 && gx <= s.x2 && gy >= s.y1 && gy <= s.y2) {
        return s;
      }
    }
    return null;
  }

  function dibujarEntornoYSuelos() {
    for (var gx = -1; gx <= MAPA_COLS; gx++) {
      for (var gy = -1; gy <= MAPA_FILAS; gy++) {
        if (gx < 0 || gy < 0 || gx >= MAPA_COLS || gy >= MAPA_FILAS) {
          var esCarretera = (gy === MAPA_FILAS && gx >= 2 && gx <= 9);
          var colExt = esCarretera
            ? ((gx + gy) % 2 === 0 ? '#334155' : '#3E4C5E')
            : ((gx + gy) % 2 === 0 ? '#15803D' : '#166534');
          dibujarLosaIsometrica(gx, gy, colExt, 'rgba(255,255,255,0.06)');
          continue;
        }

        var sala = obtenerSalaEnCelda(gx, gy);
        if (sala) {
          var par = (gx + gy) % 2 === 0;
          dibujarLosaIsometrica(gx, gy, par ? sala.colorSuelo1 : sala.colorSuelo2, 'rgba(148, 163, 184, 0.35)');
        } else {
          var parPasillo = (gx + gy) % 2 === 0;
          dibujarLosaIsometrica(gx, gy, parPasillo ? '#F8FAFC' : '#E2E8F0', 'rgba(148, 163, 184, 0.3)');
        }
      }
    }

    for (var mx = 0; mx < MAPA_COLS; mx++) {
      dibujarBloque3D(mx, -0.18, 0, 1, 0.18, 52, '#F8FAFC', '#CBD5E1', '#94A3B8');
      if (mx % 3 === 1) {
        dibujarBloque3D(mx + 0.15, -0.16, 18, 0.7, 0.19, 22, '#E0F2FE', '#38BDF8', '#7DD3FC');
      }
    }
    for (var my = 0; my < MAPA_FILAS; my++) {
      dibujarBloque3D(-0.18, my, 0, 0.18, 1, 52, '#F8FAFC', '#94A3B8', '#CBD5E1');
      if (my % 3 === 1) {
        dibujarBloque3D(-0.16, my + 0.15, 18, 0.19, 0.7, 22, '#E0F2FE', '#7DD3FC', '#38BDF8');
      }
    }

    salasHospital.forEach(function (s) {
      var puertaX = Math.floor((s.x1 + s.x2) / 2);
      var puertaY = Math.floor((s.y1 + s.y2) / 2);
      for (var tx = s.x1; tx <= s.x2; tx++) {
        if (tx !== puertaX) {
          dibujarBloque3D(tx, s.y1 - 0.12, 0, 1, 0.12, 22, '#FFFFFF', s.colorPared, '#94A3B8');
        }
      }
      for (var ty = s.y1; ty <= s.y2; ty++) {
        if (ty !== puertaY) {
          dibujarBloque3D(s.x1 - 0.12, ty, 0, 0.12, 1, 22, '#FFFFFF', '#94A3B8', s.colorPared);
        }
      }
    });
  }

  function dibujarMobiliario3D() {
    /* 1. Mostrador de Admisión y Sillas */
    dibujarBloque3D(2.0, 1.8, 0, 2.2, 0.7, 20, '#F59E0B', '#D97706', '#B45309');
    dibujarBloque3D(2.8, 1.9, 20, 0.5, 0.3, 10, '#1E293B', '#0F172A', '#334155');
    dibujarBloque3D(1.5, 4.0, 0, 0.6, 0.6, 12, '#38BDF8', '#0284C7', '#0369A1');
    dibujarBloque3D(2.4, 4.0, 0, 0.6, 0.6, 12, '#38BDF8', '#0284C7', '#0369A1');
    dibujarBloque3D(3.3, 4.0, 0, 0.6, 0.6, 12, '#38BDF8', '#0284C7', '#0369A1');

    /* 2. Consulta Clínica (Unidad 1) */
    dibujarBloque3D(7.0, 1.8, 0, 1.6, 0.8, 18, '#E2E8F0', '#94A3B8', '#64748B');
    dibujarBloque3D(8.8, 2.2, 0, 0.9, 1.8, 16, '#FFFFFF', '#38BDF8', '#0284C7');
    dibujarBloque3D(8.85, 2.25, 16, 0.8, 0.45, 4, '#F8FAFC', '#CBD5E1', '#94A3B8');

    /* 3. Farmacia Hospitalaria */
    dibujarBloque3D(1.3, 6.4, 0, 0.6, 2.8, 42, '#CCFBF1', '#0D9488', '#115E59');
    dibujarBloque3D(2.6, 6.4, 0, 2.0, 0.6, 38, '#E0F2FE', '#0284C7', '#0369A1');
    dibujarBloque3D(2.8, 8.2, 0, 1.6, 0.8, 20, '#FFFFFF', '#CBD5E1', '#94A3B8');

    /* 4. Box de Urgencias y Observación */
    dibujarBloque3D(7.8, 6.8, 0, 1.2, 2.1, 16, '#FFFFFF', '#CBD5E1', '#94A3B8');
    dibujarBloque3D(7.82, 7.4, 16, 1.16, 1.4, 3, '#FB7185', '#E11D48', '#BE123C');
    dibujarBloque3D(7.85, 6.85, 16, 1.1, 0.45, 5, '#F8FAFC', '#E2E8F0', '#CBD5E1');

    /* Monitor de Constantes Vitales con Onda ECG */
    dibujarBloque3D(9.2, 6.7, 0, 0.55, 0.55, 32, '#334155', '#1E293B', '#0F172A');
    var posECG = mundoAPantalla(9.45, 6.95, 28);
    ctx.strokeStyle = '#10B981';
    ctx.lineWidth = 2 * camara.zoom;
    ctx.beginPath();
    for (var i = -12; i <= 12; i++) {
      var onda = Math.sin((tiempoAcumulado * 6) + i * 0.6) * 4;
      if (i % 7 === 0) onda = -10;
      var ex = posECG.x + i * 1.1 * camara.zoom;
      var ey = posECG.y + onda * camara.zoom;
      if (i === -12) ctx.moveTo(ex, ey);
      else ctx.lineTo(ex, ey);
    }
    ctx.stroke();

    /* Pie de Gotero Parenteral IV */
    var baseGotero = mundoAPantalla(7.5, 7.1, 0);
    var topeGotero = mundoAPantalla(7.5, 7.1, 38);
    ctx.strokeStyle = '#64748B';
    ctx.lineWidth = 2.5 * camara.zoom;
    ctx.beginPath();
    ctx.moveTo(baseGotero.x, baseGotero.y);
    ctx.lineTo(topeGotero.x, topeGotero.y);
    ctx.stroke();
    ctx.fillStyle = '#38BDF8';
    ctx.fillRect(topeGotero.x - 5 * camara.zoom, topeGotero.y, 10 * camara.zoom, 13 * camara.zoom);

    /* 5. Ambulancia 3D exterior */
    dibujarBloque3D(5.2, 12.1, 0, 2.4, 1.1, 28, '#FFFFFF', '#E2E8F0', '#CBD5E1');
    dibujarBloque3D(7.6, 12.15, 0, 0.8, 1.0, 20, '#EF4444', '#DC2626', '#B91C1C');
    var brilloSirena = Math.sin(tiempoAcumulado * 8) > 0 ? '#EF4444' : '#3B82F6';
    dibujarBloque3D(7.3, 12.45, 28, 0.3, 0.4, 5, brilloSirena, brilloSirena, brilloSirena);
  }

  function dibujarEtiquetasSalas() {
    ctx.save();
    ctx.textAlign = 'center';
    salasHospital.forEach(function (s) {
      var cx = (s.x1 + s.x2 + 1) / 2;
      var cy = (s.y1 + s.y2 + 1) / 2;
      var pos = mundoAPantalla(cx, cy, 2);

      ctx.font = '800 ' + Math.round(12 * camara.zoom) + 'px "Segoe UI", sans-serif';
      ctx.fillStyle = 'rgba(15, 23, 42, 0.78)';
      ctx.fillText(s.nombre.toUpperCase(), pos.x, pos.y);

      ctx.font = '600 ' + Math.round(10 * camara.zoom) + 'px "Segoe UI", sans-serif';
      ctx.fillStyle = 'rgba(30, 96, 145, 0.85)';
      ctx.fillText(s.subtitulo, pos.x, pos.y + 13 * camara.zoom);
    });
    ctx.restore();
  }

  function actualizarYOrdenarActores(dt) {
    var velJuego = (FT.estado && FT.estado.obtener().hospital.velocidadJuego) !== undefined
      ? FT.estado.obtener().hospital.velocidadJuego
      : 1;
    var factorTiempo = dt * velJuego;

    actores.forEach(function (a) {
      var dx = a.destinoX - a.x;
      var dy = a.destinoY - a.y;
      var dist = Math.hypot(dx, dy);

      if (dist > 0.08 && velJuego > 0) {
        var avance = Math.min(dist, a.velocidad * factorTiempo);
        a.x += (dx / dist) * avance;
        a.y += (dy / dist) * avance;
        a.fasePaso += factorTiempo * 10;
      } else if (a.colaDestinos && a.colaDestinos.length > 0 && velJuego > 0) {
        var sig = a.colaDestinos.shift();
        a.destinoX = sig.x;
        a.destinoY = sig.y;
        if (sig.etiquetaTemporal) {
          a.etiqueta = sig.etiquetaTemporal;
        }
        if (typeof sig.alLlegar === 'function') {
          sig.alLlegar();
        }
      } else if (!a.esPaciente && velJuego > 0) {
        if (Math.random() < 0.012) {
          if (a.id === 'act_carmen') {
            a.destinoX = 2.2 + Math.random() * 2.2;
            a.destinoY = 2.4 + Math.random() * 1.6;
          }
        }
      } else {
        a.fasePaso += factorTiempo * 2.5;
      }
    });

    return actores.slice().sort(function (a, b) {
      return (a.x + a.y) - (b.x + b.y);
    });
  }

  function dibujarPersonajeProcedural(a) {
    var pos = mundoAPantalla(a.x, a.y, 0);
    var z = camara.zoom;
    var caminando = Math.hypot(a.destinoX - a.x, a.destinoY - a.y) > 0.08;
    var rebote = caminando ? Math.abs(Math.sin(a.fasePaso)) * 4 * z : Math.sin(a.fasePaso) * 1.2 * z;
    var oscilacionPierna = caminando ? Math.sin(a.fasePaso) * 5 * z : 0;
    var temblorFiebre = (a.id === 'act_paciente_neumonia' && !a.curado) ? Math.sin(tiempoAcumulado * 28) * 1.6 * z : 0;

    var cx = pos.x + temblorFiebre;
    var cy = pos.y;

    ctx.save();

    if (a.id === actorSeleccionadoId) {
      ctx.beginPath();
      ctx.ellipse(cx, cy, 20 * z, 10 * z, 0, 0, Math.PI * 2);
      ctx.strokeStyle = '#14B8A6';
      ctx.lineWidth = 3 * z;
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.ellipse(cx, cy, 13 * z, 6.5 * z, 0, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.28)';
    ctx.fill();

    ctx.lineWidth = 4.5 * z;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#1E293B';
    ctx.beginPath();
    ctx.moveTo(cx - 4.5 * z, cy - 12 * z - rebote);
    ctx.lineTo(cx - 4.5 * z - oscilacionPierna * 0.4, cy - 2 * z + oscilacionPierna * 0.5);
    ctx.moveTo(cx + 4.5 * z, cy - 12 * z - rebote);
    ctx.lineTo(cx + 4.5 * z + oscilacionPierna * 0.4, cy - 2 * z - oscilacionPierna * 0.5);
    ctx.stroke();

    trazarRectRedondeado(ctx, cx - 10 * z, cy - 31 * z - rebote, 20 * z, 20 * z, 6 * z);
    ctx.fillStyle = a.colorRopa;
    ctx.fill();
    ctx.strokeStyle = '#0F172A';
    ctx.lineWidth = 1.4 * z;
    ctx.stroke();

    if (!a.esPaciente) {
      ctx.beginPath();
      ctx.moveTo(cx - 4 * z, cy - 31 * z - rebote);
      ctx.lineTo(cx, cy - 23 * z - rebote);
      ctx.lineTo(cx + 4 * z, cy - 31 * z - rebote);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
    }

    ctx.lineWidth = 4 * z;
    ctx.strokeStyle = a.colorRopa;
    ctx.beginPath();
    ctx.moveTo(cx - 10 * z, cy - 28 * z - rebote);
    ctx.lineTo(cx - 13 * z, cy - 17 * z - rebote - oscilacionPierna * 0.4);
    ctx.moveTo(cx + 10 * z, cy - 28 * z - rebote);
    ctx.lineTo(cx + 13 * z, cy - 17 * z - rebote + oscilacionPierna * 0.4);
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy - 40 * z - rebote, 9.5 * z, 0, Math.PI * 2);
    ctx.fillStyle = a.colorPiel;
    ctx.fill();
    ctx.lineWidth = 1.4 * z;
    ctx.strokeStyle = '#0F172A';
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy - 42.5 * z - rebote, 9.8 * z, Math.PI, Math.PI * 2);
    ctx.fillStyle = a.colorPelo;
    ctx.fill();

    var parpadeo = (Math.floor(tiempoAcumulado * 2) % 7 === 0);
    ctx.fillStyle = '#0F172A';
    if (!parpadeo) {
      ctx.beginPath();
      ctx.arc(cx - 3.2 * z, cy - 40 * z - rebote, 1.3 * z, 0, Math.PI * 2);
      ctx.arc(cx + 3.2 * z, cy - 40 * z - rebote, 1.3 * z, 0, Math.PI * 2);
      ctx.fill();
    }

    if (a.id === 'act_paciente_neumonia' && !a.curado) {
      ctx.fillStyle = 'rgba(225, 29, 72, 0.35)';
      ctx.beginPath();
      ctx.arc(cx - 5 * z, cy - 37.5 * z - rebote, 2.2 * z, 0, Math.PI * 2);
      ctx.arc(cx + 5 * z, cy - 37.5 * z - rebote, 2.2 * z, 0, Math.PI * 2);
      ctx.fill();
    }

    var etiqY = cy - 58 * z - rebote;
    ctx.font = '700 ' + Math.round(10.5 * z) + 'px "Segoe UI", sans-serif';
    var anchoTexto = ctx.measureText(a.etiqueta).width + 14 * z;
    ctx.fillStyle = a.esPaciente ? 'rgba(190, 18, 60, 0.92)' : 'rgba(15, 23, 42, 0.86)';
    trazarRectRedondeado(ctx, cx - anchoTexto / 2, etiqY - 11 * z, anchoTexto, 18 * z, 9 * z);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.textAlign = 'center';
    ctx.fillText(a.etiqueta, cx, etiqY + 1.5 * z);

    ctx.restore();
  }

  function emitirTextoFlotante(wx, wy, texto, color) {
    particulas.push({
      wx: wx,
      wy: wy,
      wz: 42,
      texto: texto,
      color: color || '#10B981',
      vida: 1.6,
      vidaMax: 1.6
    });
  }

  function actualizarYDibujarParticulas(dt) {
    for (var i = particulas.length - 1; i >= 0; i--) {
      var p = particulas[i];
      p.vida -= dt;
      p.wz += dt * 24;
      if (p.vida <= 0) {
        particulas.splice(i, 1);
        continue;
      }
      var pos = mundoAPantalla(p.wx, p.wy, p.wz);
      var alpha = Math.max(0, p.vida / p.vidaMax);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.font = '800 ' + Math.round(14 * camara.zoom) + 'px "Segoe UI", sans-serif';
      ctx.fillStyle = p.color;
      ctx.textAlign = 'center';
      ctx.fillText(p.texto, pos.x, pos.y);
      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------------
     ANIMACIÓN 3D DE RONDA ENFERMERA: FARMACIA -> CAMA DEL PACIENTE
     ------------------------------------------------------------------------ */
  function ejecutarRondaEnfermeria3D(destX, destY, nivelDecision, textoRecompensa) {
    var enfermero = null;
    for (var i = 0; i < actores.length; i++) {
      if (actores[i].id === 'act_enfermero_planta') {
        enfermero = actores[i];
        break;
      }
    }
    if (!enfermero) return;

    enfermero.etiqueta = '🏃‍♂️ Yendo a Farmacia...';
    enfermero.colaDestinos = [
      {
        x: 3.4,
        y: 8.0,
        etiquetaTemporal: '💉 Medicación recogida (5 Correctos)',
        alLlegar: function () {
          emitirTextoFlotante(3.4, 8.0, '📦 Dispensado en Farmacia', '#0D9488');
        }
      },
      {
        x: destX - 0.5,
        y: destY + 0.3,
        etiquetaTemporal: '💉 Enfermero Marcos',
        alLlegar: function () {
          var col = nivelDecision === 'optima' ? '#10B981' : (nivelDecision === 'aceptable' ? '#D97706' : '#E11D48');
          emitirTextoFlotante(destX, destY, textoRecompensa + ' · ' + nivelDecision.toUpperCase(), col);
          if (nivelDecision === 'optima') {
            actores.forEach(function (pac) {
              if (pac.id === 'act_paciente_neumonia' && Math.hypot(pac.x - destX, pac.y - destY) < 1.5) {
                pac.curado = true;
                pac.colorRopa = '#10B981';
                pac.etiqueta = '✅ Afebril (36,6 °C · Estable)';
              }
            });
          }
        }
      }
    ];
  }

  var ultimoFrame = performance.now();

  function bucleRender(ahora) {
    var dt = Math.min(0.05, (ahora - ultimoFrame) / 1000);
    ultimoFrame = ahora;
    tiempoAcumulado += dt;

    if (canvas && ctx) {
      ctx.fillStyle = camara.modoNocturno ? '#091526' : '#1E3A4C';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      dibujarEntornoYSuelos();
      dibujarMobiliario3D();
      dibujarEtiquetasSalas();

      var ordenados = actualizarYOrdenarActores(dt);
      ordenados.forEach(dibujarPersonajeProcedural);

      actualizarYDibujarParticulas(dt);

      if (camara.modoNocturno) {
        ctx.fillStyle = 'rgba(15, 23, 42, 0.28)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
    }

    requestAnimationFrame(bucleRender);
  }

  function seleccionarEntidadEnCoordenadas(clientX, clientY) {
    var rect = canvas.getBoundingClientRect();
    var px = clientX - rect.left;
    var py = clientY - rect.top;

    for (var i = actores.length - 1; i >= 0; i--) {
      var a = actores[i];
      var pos = mundoAPantalla(a.x, a.y, 22);
      if (Math.hypot(px - pos.x, py - pos.y) < 36 * camara.zoom) {
        actorSeleccionadoId = a.id;
        if (FT.audio) FT.audio.tocarSeleccion();
        emitirTextoFlotante(a.x, a.y, '✓ Seleccionado', '#38BDF8');
        actualizarTarjetaInspeccion(a.avatar, a.nombre + ' · ' + a.rol, a.dialogo, a.esPaciente, a.casoId);
        if (a.esPaciente && a.casoId && FT.clinica) {
          FT.clinica.abrirConsulta(a.casoId);
        }
        return;
      }
    }

    var mundo = pantallaAMundo(px, py);
    var sala = obtenerSalaEnCelda(Math.floor(mundo.x), Math.floor(mundo.y));
    if (sala) {
      if (FT.audio) FT.audio.tocarClick();
      actualizarTarjetaInspeccion(
        '🏥',
        sala.nombre,
        'Departamento activo: ' + sala.subtitulo + '. Toca "Consulta" abajo para resolver los 6 casos clínicos de la Unidad 1.',
        false,
        null
      );
    }
  }

  function actualizarTarjetaInspeccion(icono, titulo, descripcion, mostrarBotonConsulta, casoId) {
    var elIcono = document.querySelector('.inspeccion-avatar');
    var elTit = document.getElementById('inspeccion-titulo');
    var elDesc = document.getElementById('inspeccion-descripcion');
    var btn = document.getElementById('btn-accion-inspeccion');
    if (elIcono) elIcono.textContent = icono;
    if (elTit) elTit.textContent = titulo;
    if (elDesc) elDesc.textContent = descripcion;
    if (btn) {
      btn.textContent = mostrarBotonConsulta ? '🩺 Abrir Caso' : '📖 Vademécum';
      btn.setAttribute('data-caso-id', casoId || '');
    }
  }

  function ajustarTamanoCanvas() {
    if (!canvas) return;
    canvas.width = canvas.parentElement.clientWidth || window.innerWidth;
    canvas.height = canvas.parentElement.clientHeight || (window.innerHeight - 58);
  }

  FT.render = {
    inicializar: function () {
      canvas = document.getElementById('lienzo-hospital');
      if (!canvas) return;
      ctx = canvas.getContext('2d');
      ajustarTamanoCanvas();
      window.addEventListener('resize', ajustarTamanoCanvas);

      var movioCamara = false;

      canvas.addEventListener('mousedown', function (e) {
        camara.arrastrando = true;
        movioCamara = false;
        camara.inicioX = e.clientX - camara.x;
        camara.inicioY = e.clientY - camara.y;
      });

      window.addEventListener('mousemove', function (e) {
        if (!camara.arrastrando) return;
        var nx = e.clientX - camara.inicioX;
        var ny = e.clientY - camara.inicioY;
        if (Math.hypot(nx - camara.x, ny - camara.y) > 6) movioCamara = true;
        camara.x = nx;
        camara.y = ny;
      });

      window.addEventListener('mouseup', function (e) {
        if (camara.arrastrando && !movioCamara && e.target === canvas) {
          seleccionarEntidadEnCoordenadas(e.clientX, e.clientY);
        }
        camara.arrastrando = false;
      });

      canvas.addEventListener('touchstart', function (e) {
        if (e.touches.length === 1) {
          camara.arrastrando = true;
          movioCamara = false;
          camara.inicioX = e.touches[0].clientX - camara.x;
          camara.inicioY = e.touches[0].clientY - camara.y;
        }
      }, { passive: true });

      canvas.addEventListener('touchmove', function (e) {
        if (!camara.arrastrando || e.touches.length !== 1) return;
        var nx = e.touches[0].clientX - camara.inicioX;
        var ny = e.touches[0].clientY - camara.inicioY;
        if (Math.hypot(nx - camara.x, ny - camara.y) > 8) movioCamara = true;
        camara.x = nx;
        camara.y = ny;
      }, { passive: true });

      canvas.addEventListener('touchend', function (e) {
        if (!movioCamara && e.changedTouches && e.changedTouches.length > 0) {
          var t = e.changedTouches[0];
          seleccionarEntidadEnCoordenadas(t.clientX, t.clientY);
        }
        camara.arrastrando = false;
      });

      canvas.addEventListener('wheel', function (e) {
        e.preventDefault();
        var delta = e.deltaY < 0 ? 0.1 : -0.1;
        this.cambiarZoom(delta);
      }.bind(this), { passive: false });

      requestAnimationFrame(bucleRender);
    },

    cambiarZoom: function (delta) {
      camara.zoom = FT.util.clamp(camara.zoom + delta, 0.65, 1.75);
    },

    centrarCamara: function () {
      camara.x = 0;
      camara.y = 85;
      camara.zoom = 1.0;
    },

    alternarDiaNoche: function () {
      camara.modoNocturno = !camara.modoNocturno;
      return camara.modoNocturno;
    },

    emitirTextoFlotante: emitirTextoFlotante,
    ejecutarRondaEnfermeria3D: ejecutarRondaEnfermeria3D
  };

})(window.FT = window.FT || {});