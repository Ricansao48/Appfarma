/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/01_bus_eventos.js
   Responsabilidad: Bus de eventos Pub/Sub desacoplado para comunicar Estado,
   Lógica Clínica, Motor Tycoon, Renderizador Canvas y Controlador DOM.
   ========================================================================== */

(function (FT) {
  'use strict';

  /* Catálogo centralizado de nombres de eventos para evitar errores de tipeo */
  FT.EVENTOS = Object.freeze({
    ESTADO_INICIALIZADO: 'estado:inicializado',
    ESTADO_CAMBIADO: 'estado:cambiado',
    ECONOMIA_ACTUALIZADA: 'economia:actualizada',
    REPUTACION_ACTUALIZADA: 'reputacion:actualizada',
    TIEMPO_AVANZADO: 'tiempo:avanzado',
    DOMINIO_ACTUALIZADO: 'dominio:actualizado',
    PARTIDA_GUARDADA: 'partida:guardada',
    PARTIDA_CARGADA: 'partida:cargada',
    AJUSTES_CAMBIADOS: 'ajustes:cambiados',
    VALIDACION_COMPLETADA: 'validador:completada'
  });

  var suscriptores = {};
  var historialReciente = [];
  var MAX_HISTORIAL = 25;

  FT.bus = {
    on: function (nombreEvento, callback) {
      if (!nombreEvento || typeof callback !== 'function') return function () {};
      if (!suscriptores[nombreEvento]) {
        suscriptores[nombreEvento] = [];
      }
      suscriptores[nombreEvento].push(callback);

      var self = this;
      return function desuscribir() {
        self.off(nombreEvento, callback);
      };
    },

    once: function (nombreEvento, callback) {
      var self = this;
      var envoltorio = function (datos) {
        self.off(nombreEvento, envoltorio);
        callback(datos);
      };
      return this.on(nombreEvento, envoltorio);
    },

    off: function (nombreEvento, callback) {
      if (!suscriptores[nombreEvento]) return;
      suscriptores[nombreEvento] = suscriptores[nombreEvento].filter(function (fn) {
        return fn !== callback;
      });
    },

    emit: function (nombreEvento, datos) {
      var entrada = {
        hora: new Date().toLocaleTimeString('es-ES'),
        evento: nombreEvento,
        resumen: datos ? JSON.stringify(datos).substring(0, 90) : '{}'
      };
      historialReciente.unshift(entrada);
      if (historialReciente.length > MAX_HISTORIAL) {
        historialReciente.pop();
      }

      var lista = suscriptores[nombreEvento];
      if (!lista || lista.length === 0) return;

      lista.slice().forEach(function (fn) {
        try {
          fn(datos);
        } catch (err) {
          if (FT.errores) {
            FT.errores.registrarManual(
              'Error en suscriptor de [' + nombreEvento + ']: ' + err.message,
              'js/01_bus_eventos.js'
            );
          }
        }
      });
    },

    obtenerHistorialReciente: function () {
      return historialReciente.slice();
    },

    limpiarTodo: function () {
      suscriptores = {};
      historialReciente = [];
    }
  };

})(window.FT = window.FT || {});