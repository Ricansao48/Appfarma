/* ==========================================================================
   VADEMÉCUM TYCOON: DIRECCIÓN CLÍNICA
   Archivo: js/16_herramientas_debug_main.js
   Responsabilidad: Inicializador general, conexión con FT.clinica (6 casos
   Unidad 1 + Vademécum con buscador) y Panel de Trucos (F9 / táctil).
   ========================================================================== */

(function (FT) {
  'use strict';

  function mostrarModalTrucosF9() {
    var backdrop = document.getElementById('modal-backdrop');
    var elTitulo = document.getElementById('modal-titulo');
    var elCuerpo = document.getElementById('modal-contenido');
    if (!backdrop || !elTitulo || !elCuerpo) return;

    elTitulo.textContent = '🛠️ Panel de Trucos y Pruebas Rápidas (F9)';
    elCuerpo.innerHTML =
      '<p class="texto-secundario">Herramientas de desarrollo para probar la economía, la delegación automática por dominio y el capturador de errores:</p>' +
      '<div class="grupo-botones-prueba">' +
        '<button type="button" class="btn btn-exito btn-sm" id="cheat-dinero">+10.000 € Presupuesto</button>' +
        '<button type="button" class="btn btn-primario btn-sm" id="cheat-reputacion">+100 Reputación (★)</button>' +
        '<button type="button" class="btn btn-secundario btn-sm" id="cheat-dia">◷ Avanzar +1 Día</button>' +
        '<button type="button" class="btn btn-primario btn-sm" id="cheat-dominio">◈ Subir Dominio U1 al 85% (Activar Delegación)</button>' +
        '<button type="button" class="btn btn-danino btn-sm" id="cheat-error">🐞 Probar Capturador de Error</button>' +
      '</div>';

    backdrop.classList.remove('oculto');

    document.getElementById('cheat-dinero').addEventListener('click', function () {
      FT.estado.modificarDinero(10000, 'Truco F9');
      if (FT.audio) FT.audio.tocarExitoMonedas();
      FT.util.mostrarToast('+10.000 € añadidos al hospital.');
    });

    document.getElementById('cheat-reputacion').addEventListener('click', function () {
      FT.estado.modificarReputacion(100, 'Truco F9');
      FT.util.mostrarToast('+100 puntos de Reputación.');
    });

    document.getElementById('cheat-dia').addEventListener('click', function () {
      FT.estado.avanzarTiempoMinutos(1440);
      FT.util.mostrarToast('Avanzado 1 día completo de guardia.');
    });

    document.getElementById('cheat-dominio').addEventListener('click', function () {
      ['t1', 't2', 't3', 't4'].forEach(function (t) {
        FT.estado.registrarProgresoTema(t, 85);
      });
      FT.util.mostrarToast('Dominio de la Unidad 1 al 85% (Plata): Delegación en Enfermero Marcos desbloqueada.');
    });

    document.getElementById('cheat-error').addEventListener('click', function () {
      FT.errores.simularErrorPrueba();
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    if (FT.render) {
      FT.render.inicializar();
    }
    if (FT.clinica) {
      FT.clinica.actualizarBoton();
    }

    var modoElegido = 'campana';
    document.querySelectorAll('.modo-card').forEach(function (card) {
      card.addEventListener('click', function () {
        document.querySelectorAll('.modo-card').forEach(function (c) { c.classList.remove('activo'); });
        card.classList.add('activo');
        modoElegido = card.getAttribute('data-modo');
        if (FT.audio) FT.audio.tocarClick();
      });
    });

    var btnIniciar = document.getElementById('btn-iniciar-hospital');
    if (btnIniciar) {
      btnIniciar.addEventListener('click', function () {
        var overlay = document.getElementById('pantalla-titulo');
        if (overlay) overlay.classList.add('oculto');
        var est = FT.estado.obtener();
        est.meta.modoJuego = modoElegido;
        var sub = document.getElementById('hud-subtitulo-fase');
        if (sub) {
          var mapaNombres = { campana: 'Modo Campaña', estudio: 'Modo Estudio', guardia: 'Modo Guardia' };
          sub.textContent = (mapaNombres[modoElegido] || 'Modo Campaña') + ' · Unidad 1 (6 Casos)';
        }
        if (FT.audio) FT.audio.tocarExitoMonedas();
      });
    }

    document.getElementById('btn-zoom-in').addEventListener('click', function () {
      FT.render.cambiarZoom(0.15);
      if (FT.audio) FT.audio.tocarClick();
    });
    document.getElementById('btn-zoom-out').addEventListener('click', function () {
      FT.render.cambiarZoom(-0.15);
      if (FT.audio) FT.audio.tocarClick();
    });
    document.getElementById('btn-camara-centrar').addEventListener('click', function () {
      FT.render.centrarCamara();
      if (FT.audio) FT.audio.tocarClick();
    });
    document.getElementById('btn-ciclo-luz').addEventListener('click', function () {
      var nocturno = FT.render.alternarDiaNoche();
      this.textContent = nocturno ? '🌙 Noche' : '☀️ Día';
      if (FT.audio) FT.audio.tocarClick();
    });

    document.getElementById('btn-toggle-audio').addEventListener('click', function () {
      var sil = FT.audio.alternarSilencio();
      this.textContent = sil ? '🔇 Mudo' : '🔊 Audio';
    });

    document.getElementById('btn-dock-consulta').addEventListener('click', function () {
      if (FT.audio) FT.audio.tocarSeleccion();
      if (FT.clinica) FT.clinica.abrirConsulta();
    });

    document.getElementById('btn-accion-inspeccion').addEventListener('click', function () {
      if (FT.audio) FT.audio.tocarSeleccion();
      var casoId = this.getAttribute('data-caso-id');
      if (FT.clinica) {
        if (casoId) FT.clinica.abrirConsulta(casoId);
        else FT.clinica.abrirConsulta();
      }
    });

    document.getElementById('btn-dock-vademecum').addEventListener('click', function () {
      if (FT.audio) FT.audio.tocarClick();
      if (FT.clinica) FT.clinica.abrirVademecum();
    });

    document.getElementById('btn-cerrar-panel-derecho').addEventListener('click', function () {
      var panel = document.getElementById('panel-clinico-derecho');
      if (panel) panel.classList.add('panel-plegado');
    });

    document.getElementById('btn-dock-trucos').addEventListener('click', mostrarModalTrucosF9);

    window.addEventListener('keydown', function (e) {
      if (e.key === 'F9') {
        e.preventDefault();
        mostrarModalTrucosF9();
      }
    });

    document.querySelectorAll('.btn-velocidad').forEach(function (b) {
      b.addEventListener('click', function () {
        var vel = Number(b.getAttribute('data-vel'));
        FT.estado.obtener().hospital.velocidadJuego = vel;
        document.querySelectorAll('.btn-velocidad').forEach(function (x) {
          x.classList.remove('btn-primario');
          x.classList.add('btn-secundario');
        });
        b.classList.remove('btn-secundario');
        b.classList.add('btn-primario');
        if (FT.audio) FT.audio.tocarClick();
      });
    });
  });

})(window.FT = window.FT || {});